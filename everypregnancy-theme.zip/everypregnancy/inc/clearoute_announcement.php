<?php
/**
 * Site announcement bar wiring.
 *
 * Registers an ACF Options page so the sitewide announcement (eyebrow, body,
 * CTA, icon) is editable, exposes a default-data helper that the template-part
 * falls back to when Options haven't been filled in yet, and enqueues the
 * announcement stylesheet.
 *
 * Pattern mirrors inc/clearoute_header.php and inc/clearoute_footer.php.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the "Announcement Bar" ACF Options page (Pro feature; falls back
 * silently when ACF Pro isn't installed).
 */
function everypregnancy_register_announcement_options_page() {
	if ( ! function_exists( 'acf_add_options_page' ) ) {
		return;
	}

	acf_add_options_page( array(
		'page_title'  => __( 'Announcement Bar', 'everypregnancy' ),
		'menu_title'  => __( 'Announcement Bar', 'everypregnancy' ),
		'menu_slug'   => 'everypregnancy-announcement-settings',
		'parent_slug' => 'themes.php',
		'capability'  => 'edit_theme_options',
		'redirect'    => false,
	) );
}
add_action( 'acf/init', 'everypregnancy_register_announcement_options_page' );

/**
 * Canonical defaults for the announcement bar.
 *
 * @return array
 */
function everypregnancy_announcement_defaults() {
	return array(
		'show'        => true,
		'icon'        => EVERYPREGNANCY_URI . '/src/img/announcement-icon.png',
		'icon_alt'    => __( 'Mother and baby', 'everypregnancy' ),
		'eyebrow'     => __( 'Syria Reborn:', 'everypregnancy' ),
		'body'        => __( 'As Syria rebuilds, moms and babies need our full attention, resources, and support.', 'everypregnancy' ),
		'body_mobile' => __( 'Discover our latest campaign', 'everypregnancy' ),
		'cta_label'   => __( 'View Campaign', 'everypregnancy' ),
		'cta_url'     => home_url( '/pakistan-pledge/' ),
	);
}

/**
 * Reads an announcement field from ACF Options when available; falls back
 * to defaults otherwise.
 *
 * @param string $name Field name (without the `announcement_` prefix).
 * @return mixed
 */
function everypregnancy_announcement_field( $name ) {
	$defaults = everypregnancy_announcement_defaults();
	$default  = $defaults[ $name ] ?? '';

	if ( function_exists( 'get_field' ) ) {
		$value = get_field( 'announcement_' . $name, 'option' );

		// Image field — normalise to URL.
		if ( $name === 'icon' ) {
			if ( is_array( $value ) && ! empty( $value['url'] ) ) {
				return $value['url'];
			}
			if ( is_numeric( $value ) ) {
				$src = wp_get_attachment_image_url( (int) $value, 'full' );
				if ( $src ) {
					return $src;
				}
			}
			if ( is_string( $value ) && $value !== '' ) {
				return $value;
			}
			return $default;
		}

		// Boolean — explicit null check so "false" is respected.
		if ( $name === 'show' ) {
			if ( $value === null ) {
				return $default;
			}
			return (bool) $value;
		}

		if ( $value !== null && $value !== '' && $value !== false ) {
			return $value;
		}
	}

	return $default;
}

/**
 * Enqueue the announcement stylesheet.
 */
function everypregnancy_enqueue_announcement_assets() {
	$css_path = EVERYPREGNANCY_DIR . '/template-parts/site-announcement.css';
	$css_uri  = EVERYPREGNANCY_URI . '/template-parts/site-announcement.css';

	if ( ! file_exists( $css_path ) ) {
		return;
	}

	wp_register_style(
		'everypregnancy-announcement',
		$css_uri,
		array(),
		filemtime( $css_path )
	);
	wp_enqueue_style( 'everypregnancy-announcement' );
}
add_action( 'wp_enqueue_scripts', 'everypregnancy_enqueue_announcement_assets' );
