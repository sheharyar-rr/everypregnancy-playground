<?php
/**
 * Site header wiring.
 *
 * Registers an ACF Options page so the sitewide header (logo, nav items, CTA)
 * is editable, exposes a default-data helper that the template-part falls
 * back to when Options haven't been filled in yet, and enqueues the header
 * stylesheet.
 *
 * Note: This module is intentionally kept self-contained — the only change to
 * functions.php is a single require_once for this file.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the "Header Settings" ACF Options page (Pro feature; falls back
 * silently when ACF Pro isn't installed).
 */
function everypregnancy_register_header_options_page() {
	if ( ! function_exists( 'acf_add_options_page' ) ) {
		return;
	}

	acf_add_options_page( array(
		'page_title'  => __( 'Header Settings', 'everypregnancy' ),
		'menu_title'  => __( 'Header Settings', 'everypregnancy' ),
		'menu_slug'   => 'everypregnancy-header-settings',
		'parent_slug' => 'themes.php',
		'capability'  => 'edit_theme_options',
		'redirect'    => false,
	) );
}
add_action( 'acf/init', 'everypregnancy_register_header_options_page' );

/**
 * Canonical defaults for the site header. The template-part calls this and
 * overrides individual values with whatever's set on the Options page (when
 * ACF Pro is available). Keeps the demo rendering correctly without any
 * editor configuration.
 *
 * @return array
 */
function everypregnancy_header_defaults() {
	return array(
		'logo'      => EVERYPREGNANCY_URI . '/src/img/everypregnancy-logo.png',
		'logo_alt'  => __( 'EveryPregnancy', 'everypregnancy' ),
		'nav_html'  => '<ul>'
			. '<li><a href="' . esc_url( home_url( '/about-us/' ) ) . '">Who We Are</a></li>'
			. '<li><a href="' . esc_url( home_url( '/' ) ) . '">What We Do</a></li>'
			. '<li class="has-children"><a href="' . esc_url( home_url( '/partners/' ) ) . '">Our Partners</a>'
				. '<ul class="ep-site-header__submenu">'
					. '<li><a href="' . esc_url( home_url( '/partners/' ) ) . '">Partners</a></li>'
					. '<li><a href="' . esc_url( home_url( '/pakistan-pledge/' ) ) . '">All Countries</a></li>'
				. '</ul>'
			. '</li>'
			. '<li><a href="' . esc_url( home_url( '/take-action/' ) ) . '">Join the Coalition</a></li>'
			. '<li><a href="' . esc_url( home_url( '/blogs/' ) ) . '">News &amp; Events</a></li>'
			. '</ul>',
		'cta_label' => __( 'Donate Now', 'everypregnancy' ),
		'cta_url'   => home_url( '/take-action/' ),
	);
}

/**
 * Reads a header field from the ACF Options page when ACF is installed; falls
 * back to the default helper otherwise. Centralised so the template-part
 * stays clean.
 *
 * The `header_logo` field is an image (returns an attachment array or ID
 * depending on the field's return format); the helper normalises it to a URL
 * string and falls back to the bundled logo when missing.
 *
 * @param string $name  Field name (without the `header_` prefix).
 * @return mixed
 */
function everypregnancy_header_field( $name ) {
	$defaults = everypregnancy_header_defaults();
	$default  = $defaults[ $name ] ?? '';

	if ( function_exists( 'get_field' ) ) {
		$value = get_field( 'header_' . $name, 'option' );

		// Special handling for the image field — return URL string.
		if ( $name === 'logo' ) {
			if ( is_array( $value ) && ! empty( $value['url'] ) ) {
				return $value['url'];
			}
			if ( is_numeric( $value ) ) {
				$src = wp_get_attachment_image_url( (int) $value, 'full' );
				if ( $src ) {
					return $src;
				}
			}
			if ( is_string( $value ) && $value !== '' ) {
				return $value;
			}
			return $default;
		}

		if ( $value !== null && $value !== '' && $value !== false ) {
			return $value;
		}
	}

	return $default;
}

/**
 * Register + enqueue the header stylesheet on the front-end. We piggy-back
 * the existing main stylesheet handle as a dependency so cascade order is
 * predictable.
 */
function everypregnancy_enqueue_header_assets() {
	$css_path = EVERYPREGNANCY_DIR . '/template-parts/site-header.css';
	$css_uri  = EVERYPREGNANCY_URI . '/template-parts/site-header.css';

	if ( ! file_exists( $css_path ) ) {
		return;
	}

	wp_register_style(
		'everypregnancy-header',
		$css_uri,
		array(),
		filemtime( $css_path )
	);
	wp_enqueue_style( 'everypregnancy-header' );
}
add_action( 'wp_enqueue_scripts', 'everypregnancy_enqueue_header_assets' );
