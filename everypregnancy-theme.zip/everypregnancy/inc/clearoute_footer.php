<?php
/**
 * Site footer wiring.
 *
 * Registers an ACF Options page so the sitewide footer is editable, exposes a
 * default-data helper that the template-part falls back to when Options
 * haven't been filled in yet, and enqueues the footer stylesheet.
 *
 * Note: This module is intentionally kept self-contained — the only change to
 * functions.php is a single require_once for this file.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the "Footer Settings" ACF Options page (Pro feature; falls back
 * silently when ACF Pro isn't installed).
 */
function everypregnancy_register_footer_options_page() {
	if ( ! function_exists( 'acf_add_options_page' ) ) {
		return;
	}

	acf_add_options_page( array(
		'page_title'  => __( 'Footer Settings', 'everypregnancy' ),
		'menu_title'  => __( 'Footer Settings', 'everypregnancy' ),
		'menu_slug'   => 'everypregnancy-footer-settings',
		'parent_slug' => 'themes.php',
		'capability'  => 'edit_theme_options',
		'redirect'    => false,
	) );
}
add_action( 'acf/init', 'everypregnancy_register_footer_options_page' );

/**
 * Canonical defaults for the site footer. The template-part calls this and
 * overrides individual values with whatever's set on the Options page (when
 * ACF Pro is available). Keeps the demo rendering correctly without any
 * editor configuration.
 *
 * @return array
 */
function everypregnancy_footer_defaults() {
	return array(
		'quick_links_heading' => __( 'Quick Links', 'everypregnancy' ),
		'quick_links_html'    => '<ul>'
			. '<li><a href="/privacy-policy/">Privacy Policy</a></li>'
			. '<li><a href="/unsolicited-messages-policy/">Unsolicited Messages Policy</a></li>'
			. '<li><a href="/terms/">Terms</a></li>'
			. '<li><a href="/photo-credits/">Photo Credits</a></li>'
			. '<li><a href="/careers/">Careers</a></li>'
			. '</ul>',
		'contact_heading'     => __( 'Contact Us', 'everypregnancy' ),
		'contact_email'       => 'info@everypregnancy.org',
		'social_heading'      => __( 'Follow Us', 'everypregnancy' ),
		'social_instagram'    => 'https://www.instagram.com/everypregnancy/',
		'social_facebook'     => 'https://www.facebook.com/everypregnancy/',
		'social_tiktok'       => 'https://www.tiktok.com/@everypregnancy',
		'social_youtube'      => 'https://www.youtube.com/@everypregnancy',
		'social_linkedin'     => 'https://www.linkedin.com/company/everypregnancy/',
		'copyright_text'      => '©{year} EveryPregnancy • All Rights Reserved',
	);
}

/**
 * Reads a footer field from the ACF Options page when ACF is installed; falls
 * back to the default helper otherwise. Centralised so the template-part
 * stays clean.
 *
 * @param string $name  Field name (without the `footer_` prefix).
 * @return mixed
 */
function everypregnancy_footer_field( $name ) {
	$defaults = everypregnancy_footer_defaults();
	$default  = $defaults[ $name ] ?? '';

	if ( function_exists( 'get_field' ) ) {
		$value = get_field( 'footer_' . $name, 'option' );
		if ( $value !== null && $value !== '' && $value !== false ) {
			return $value;
		}
	}

	return $default;
}

/**
 * Register + enqueue the footer stylesheet on the front-end. We piggy-back
 * the existing main stylesheet handle as a dependency so cascade order is
 * predictable.
 */
function everypregnancy_enqueue_footer_assets() {
	$css_path = EVERYPREGNANCY_DIR . '/template-parts/site-footer.css';
	$css_uri  = EVERYPREGNANCY_URI . '/template-parts/site-footer.css';

	if ( ! file_exists( $css_path ) ) {
		return;
	}

	wp_register_style(
		'everypregnancy-footer',
		$css_uri,
		array(),
		filemtime( $css_path )
	);
	wp_enqueue_style( 'everypregnancy-footer' );
}
add_action( 'wp_enqueue_scripts', 'everypregnancy_enqueue_footer_assets' );
