<?php
/**
 * EveryPregnancy theme bootstrap.
 *
 * Built with the Clearoute classic-theme pattern: thin functions.php that
 * conditionally requires modules from inc/. Function naming uses the
 * `everypregnancy_` prefix per WP standards. ACF block registration is
 * guarded so the theme degrades gracefully if ACF isn't installed.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'EVERYPREGNANCY_VERSION', '0.1.0' );
define( 'EVERYPREGNANCY_DIR', get_template_directory() );
define( 'EVERYPREGNANCY_URI', get_template_directory_uri() );

require_once EVERYPREGNANCY_DIR . '/inc/clearoute_announcement.php';
require_once EVERYPREGNANCY_DIR . '/inc/clearoute_header.php';
require_once EVERYPREGNANCY_DIR . '/inc/clearoute_footer.php';

/**
 * Theme setup. Runs on after_setup_theme.
 */
function everypregnancy_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'align-wide' );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'everypregnancy' ),
	) );
}
add_action( 'after_setup_theme', 'everypregnancy_setup' );

/**
 * Front-end asset enqueue.
 */
function everypregnancy_enqueue_assets() {
	$css_path = EVERYPREGNANCY_DIR . '/build/css/main.css';
	$css_uri  = EVERYPREGNANCY_URI . '/build/css/main.css';

	if ( file_exists( $css_path ) ) {
		wp_enqueue_style(
			'everypregnancy-main',
			$css_uri,
			array(),
			filemtime( $css_path )
		);
	}
}
add_action( 'wp_enqueue_scripts', 'everypregnancy_enqueue_assets' );

/**
 * Where ACF should sync its field-group JSON. Auto-creates the dir.
 */
function everypregnancy_acf_json_save_point( $path ) {
	$dir = EVERYPREGNANCY_DIR . '/acf-json';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	return $dir;
}
add_filter( 'acf/settings/save_json', 'everypregnancy_acf_json_save_point' );

function everypregnancy_acf_json_load_point( $paths ) {
	unset( $paths[0] );
	$paths[] = EVERYPREGNANCY_DIR . '/acf-json';
	return $paths;
}
add_filter( 'acf/settings/load_json', 'everypregnancy_acf_json_load_point' );

/**
 * Auto-discover and register every block in blocks/<slug>/block.json. The
 * render_callback loads the template specified in block.json's
 * `acf.renderTemplate` (or falls back to {slug}.php) and exposes the same
 * variables ACF would: $block, $is_preview, $post_id. ACF's get_field()
 * still works inside the template via the block's data array.
 */
function everypregnancy_register_blocks() {
	$blocks_dir = EVERYPREGNANCY_DIR . '/blocks';
	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}

	foreach ( scandir( $blocks_dir ) as $slug ) {
		if ( $slug === '.' || $slug === '..' ) {
			continue;
		}
		$block_json = $blocks_dir . '/' . $slug . '/block.json';
		if ( ! file_exists( $block_json ) ) {
			continue;
		}

		$config         = json_decode( file_get_contents( $block_json ), true );
		$render_tpl     = $config['acf']['renderTemplate'] ?? ( $slug . '.php' );
		$tpl_path       = $blocks_dir . '/' . $slug . '/' . $render_tpl;

		register_block_type( $block_json, array(
			'render_callback' => function ( $attributes, $content, $block_instance ) use ( $tpl_path ) {
				if ( ! file_exists( $tpl_path ) ) {
					return '';
				}

				// Prime ACF with the block instance's saved field values so
				// get_field() inside the template returns user-edited content
				// rather than the JSON defaults.
				$block      = array_merge(
					array( 'data' => $attributes['data'] ?? array() ),
					$attributes
				);
				$is_preview = ! empty( $attributes['mode'] ) && $attributes['mode'] === 'preview';
				$post_id    = get_the_ID();

				if ( ! empty( $block['data'] ) && function_exists( 'acf_setup_meta' ) ) {
					acf_setup_meta( $block['data'], $block_instance->name ?? 'block', true );
				}

				ob_start();
				include $tpl_path;
				$out = ob_get_clean();

				if ( ! empty( $block['data'] ) && function_exists( 'acf_reset_meta' ) ) {
					acf_reset_meta( $block_instance->name ?? 'block' );
				}

				return $out;
			},
		) );
	}
}
add_action( 'init', 'everypregnancy_register_blocks' );

/**
 * Helper used in block templates: echo a value if non-empty, otherwise echo
 * the placeholder when the block is rendered in the editor preview.
 */
function everypregnancy_field_or_preview( $field, $preview = '' ) {
	$value = get_field( $field );
	if ( $value ) {
		return $value;
	}
	if ( ( function_exists( 'is_admin' ) && is_admin() ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return $preview;
	}
	return '';
}
