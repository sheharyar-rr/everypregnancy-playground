<?php
/**
 * Preview content for the Safe Promise block — used in the Gutenberg editor
 * and as a fallback in the renderer when fields are empty so the block always
 * shows something sensible. Source: Figma EveryPregnancy design (node 6729:1393).
 *
 * @package EveryPregnancy
 */

return array(
	'eyebrow'              => '',
	'heading'              => 'A world where every pregnancy is safe',
	'heading_script_word'  => 'safe',
	'intro'                => 'Every Pregnancy envisions a world where mothers everywhere thrive. We work to:',
	'mission_list'         => "<ul>\n<li>Expand the chorus of voices championing high quality maternal and newborn health care</li>\n<li>Mobilize and channel resources to increase access to lifesaving care for those who need it most</li>\n<li>Scale high-quality interventions to put an end to preventable maternal death in the most impacted countries</li>\n</ul>",
	'cta_label'            => 'Learn More',
	'cta_url'              => '#learn-more',
);
