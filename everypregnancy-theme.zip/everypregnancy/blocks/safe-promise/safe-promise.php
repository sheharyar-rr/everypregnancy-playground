<?php
/**
 * Safe Promise — mission statement section.
 *
 * Right-aligned heading with a cursive-script accent on a single word
 * ("safe"), followed by an intro sentence, a 3-item mission bullet list,
 * and a pink "Learn More" CTA. Tokens come from theme.json + the extracted
 * design-tokens.json (Figma → block via Warpspeed pipeline).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$eyebrow             = get_field( 'eyebrow' );
$heading             = get_field( 'heading' );
$heading_script_word = get_field( 'heading_script_word' );
$intro               = get_field( 'intro' );
$mission_list        = get_field( 'mission_list' );
$cta_label           = get_field( 'cta_label' );
$cta_url             = get_field( 'cta_url' );
$image               = get_field( 'image' );

// Editor preview fallbacks.
if ( ! empty( $is_preview ) ) {
	$preview = require __DIR__ . '/preview_data.php';
	$eyebrow             = $eyebrow             ?: $preview['eyebrow'];
	$heading             = $heading             ?: $preview['heading'];
	$heading_script_word = $heading_script_word ?: $preview['heading_script_word'];
	$intro               = $intro               ?: $preview['intro'];
	$mission_list        = $mission_list        ?: $preview['mission_list'];
	$cta_label           = $cta_label           ?: $preview['cta_label'];
	$cta_url             = $cta_url             ?: $preview['cta_url'];
}

// Bundled photo fallback (Figma references one but the asset 500s in the
// Dev Mode renderer; a designer-supplied replacement should be uploaded via
// the ACF image field). Returns URL or null.
$bundled_photo_path = get_template_directory() . '/src/img/safe-promise-photo.png';
$bundled_photo_uri  = file_exists( $bundled_photo_path ) ? get_template_directory_uri() . '/src/img/safe-promise-photo.png' : '';

// Build the heading markup, wrapping the script word in a span so CSS can
// style it. Case-insensitive, whole-word match on the first occurrence only,
// to avoid mangling text like "safer" or accidentally double-wrapping.
$heading_html = '';
if ( $heading ) {
	$plain = wp_strip_all_tags( $heading );
	if ( $heading_script_word ) {
		$pattern = '/\b(' . preg_quote( $heading_script_word, '/' ) . ')\b/iu';
		$replaced = preg_replace(
			$pattern,
			'<span class="ep-safe-promise__script">$1</span>',
			$plain,
			1,
			$count
		);
		$heading_html = $count ? $replaced : esc_html( $plain );
	} else {
		$heading_html = esc_html( $plain );
	}
}

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'safe-promise-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-safe-promise">
	<div class="ep-safe-promise__media" aria-hidden="<?php echo $image ? 'false' : 'true'; ?>">
		<?php if ( $image && is_array( $image ) ) : ?>
			<img class="ep-safe-promise__media-img"
				src="<?php echo esc_url( $image['sizes']['large'] ?? $image['url'] ); ?>"
				alt="<?php echo esc_attr( $image['alt'] ?? '' ); ?>" />
		<?php elseif ( $bundled_photo_uri ) : ?>
			<img class="ep-safe-promise__media-img"
				src="<?php echo esc_url( $bundled_photo_uri ); ?>"
				alt="" />
		<?php else : ?>
			<div class="ep-safe-promise__media-placeholder" aria-hidden="true"></div>
		<?php endif; ?>
	</div>

	<div class="ep-safe-promise__inner">
		<?php if ( $eyebrow ) : ?>
			<p class="ep-safe-promise__eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
		<?php endif; ?>

		<?php if ( $heading_html ) : ?>
			<h2 class="ep-safe-promise__heading">
				<?php
				// $heading_html contains escaped text plus our trusted span wrapper.
				echo wp_kses(
					$heading_html,
					array(
						'span' => array( 'class' => array() ),
						'br'   => array(),
					)
				);
				?>
			</h2>
		<?php endif; ?>

		<?php if ( $intro ) : ?>
			<p class="ep-safe-promise__intro"><?php echo esc_html( $intro ); ?></p>
		<?php endif; ?>

		<?php if ( $mission_list ) : ?>
			<div class="ep-safe-promise__list">
				<?php echo wp_kses_post( $mission_list ); ?>
			</div>
		<?php endif; ?>

		<?php if ( $cta_label ) : ?>
			<a class="ep-safe-promise__cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>
	</div>
</section>
