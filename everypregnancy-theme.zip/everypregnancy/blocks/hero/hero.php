<?php
/**
 * Hero — For Mama Challenge.
 *
 * Renders a two-column hero: left = copy + donation widget + CTA, right =
 * brand-color image area with a video play affordance. A circular Zakat
 * Eligible badge floats between the columns. Tokens come from theme.json +
 * the extracted design-tokens.json (Figma → block via Warpspeed pipeline).
 *
 * @package EveryPregnancy
 *
 * @var array  $block      The full block array.
 * @var bool   $is_preview Whether the block is rendering in the editor.
 */

$heading       = get_field( 'heading' );
$subhead       = get_field( 'subhead' );
$body          = get_field( 'body' );
$cta_label     = get_field( 'cta_label' );
$cta_url       = get_field( 'cta_url' );
$image         = get_field( 'image' );
$video_url     = get_field( 'video_url' );

$donation_show                = get_field( 'donation_show' );
$donation_last_donation_label = get_field( 'donation_last_donation_label' );
$donation_donor_count         = get_field( 'donation_donor_count' );
$donation_raised              = get_field( 'donation_raised' );
$donation_goal                = get_field( 'donation_goal' );
$donation_boosted             = get_field( 'donation_boosted' );
$donation_currency            = get_field( 'donation_currency' );

$zakat_show         = get_field( 'zakat_show' );
$zakat_label_line_1 = get_field( 'zakat_label_line_1' );
$zakat_label_line_2 = get_field( 'zakat_label_line_2' );

/*
 * For blocks already saved to a post BEFORE these fields existed, ACF stores
 * nothing under the new keys, so get_field() returns null. Treat "never set"
 * as "use the default" instead of "hide" — keeps the widget visible without
 * needing the homepage post to be re-saved.
 */
$preview_defaults = require __DIR__ . '/preview_data.php';

if ( null === $donation_show ) {
	$donation_show = $preview_defaults['donation_show'];
}
if ( null === $donation_last_donation_label || '' === $donation_last_donation_label ) {
	$donation_last_donation_label = $preview_defaults['donation_last_donation_label'];
}
if ( null === $donation_donor_count || '' === $donation_donor_count ) {
	$donation_donor_count = $preview_defaults['donation_donor_count'];
}
if ( null === $donation_raised || '' === $donation_raised ) {
	$donation_raised = $preview_defaults['donation_raised'];
}
if ( null === $donation_goal || '' === $donation_goal ) {
	$donation_goal = $preview_defaults['donation_goal'];
}
if ( null === $donation_boosted || '' === $donation_boosted ) {
	$donation_boosted = $preview_defaults['donation_boosted'];
}
if ( null === $donation_currency || '' === $donation_currency ) {
	$donation_currency = $preview_defaults['donation_currency'];
}
if ( null === $zakat_show ) {
	$zakat_show = $preview_defaults['zakat_show'];
}
if ( null === $zakat_label_line_1 || '' === $zakat_label_line_1 ) {
	$zakat_label_line_1 = $preview_defaults['zakat_label_line_1'];
}
if ( null === $zakat_label_line_2 || '' === $zakat_label_line_2 ) {
	$zakat_label_line_2 = $preview_defaults['zakat_label_line_2'];
}

// Editor preview fallbacks (heading/subhead/body/cta only — donation + zakat
// already fall back via the unset-default block above).
if ( ! empty( $is_preview ) ) {
	$heading   = $heading   ?: $preview_defaults['heading'];
	$subhead   = $subhead   ?: $preview_defaults['subhead'];
	$body      = $body      ?: $preview_defaults['body'];
	$cta_label = $cta_label ?: $preview_defaults['cta_label'];
}

// Compute progress bar percentage (clamped 0–100, no division by zero).
$donation_goal_int = max( 1, (int) $donation_goal );
$progress_pct      = max( 0, min( 100, ( (float) $donation_raised / $donation_goal_int ) * 100 ) );

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'hero-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-hero">
	<div class="ep-hero__text">
		<?php if ( $heading ) : ?>
			<?php /* ACF's `new_lines: "br"` field config already converts \n to <br />.
			 * No PHP-level conversion needed here. */ ?>
			<h1 class="ep-hero__heading"><?php echo wp_kses_post( $heading ); ?></h1>
		<?php endif; ?>

		<?php if ( $subhead ) : ?>
			<p class="ep-hero__subhead"><?php echo wp_kses_post( $subhead ); ?></p>
		<?php endif; ?>

		<?php if ( $body ) : ?>
			<div class="ep-hero__body"><?php echo wp_kses_post( $body ); ?></div>
		<?php endif; ?>

		<?php if ( $donation_show ) : ?>
			<div class="ep-hero__donation" role="group" aria-label="<?php esc_attr_e( 'Donation progress', 'everypregnancy' ); ?>">
				<div class="ep-hero__donation-meta">
					<?php if ( $donation_last_donation_label ) : ?>
						<span class="ep-hero__donation-last"><?php echo esc_html( $donation_last_donation_label ); ?></span>
					<?php endif; ?>
					<?php if ( '' !== (string) $donation_donor_count ) : ?>
						<span class="ep-hero__donation-count"><?php echo esc_html( number_format_i18n( (int) $donation_donor_count ) ); ?></span>
					<?php endif; ?>
				</div>

				<div class="ep-hero__donation-bar"
					role="progressbar"
					aria-valuemin="0"
					aria-valuemax="<?php echo esc_attr( (int) $donation_goal_int ); ?>"
					aria-valuenow="<?php echo esc_attr( (int) $donation_raised ); ?>"
					aria-label="<?php echo esc_attr( sprintf( __( '%1$s%2$s raised of %1$s%3$s goal', 'everypregnancy' ), $donation_currency, number_format_i18n( (int) $donation_raised ), number_format_i18n( (int) $donation_goal_int ) ) ); ?>">
					<span class="ep-hero__donation-bar-fill" style="width: <?php echo esc_attr( number_format( $progress_pct, 2, '.', '' ) ); ?>%;"></span>
				</div>

				<p class="ep-hero__donation-amounts">
					<span class="ep-hero__donation-raised"><?php echo esc_html( $donation_currency . number_format_i18n( (int) $donation_raised ) ); ?> raised</span>
					<span class="ep-hero__donation-goal"> of <?php echo esc_html( $donation_currency . number_format_i18n( (int) $donation_goal_int ) ); ?></span>
				</p>

				<?php if ( '' !== (string) $donation_boosted && (int) $donation_boosted > 0 ) : ?>
					<span class="ep-hero__donation-boost">
						<svg class="ep-hero__donation-boost-icon" viewBox="0 0 20 20" width="14" height="14" focusable="false" aria-hidden="true">
							<path d="M2 3h2.2l.6 2H17a1 1 0 0 1 1 1.2l-1.4 5.6a1 1 0 0 1-1 .8H7l.4 1.4H16v2H7a2 2 0 0 1-2-1.5L3.2 5H2V3zm5 14a1.6 1.6 0 1 1 0 3.2A1.6 1.6 0 0 1 7 17zm8 0a1.6 1.6 0 1 1 0 3.2A1.6 1.6 0 0 1 15 17z" fill="currentColor"/>
						</svg>
						<span class="ep-hero__donation-boost-text"><?php echo esc_html( $donation_currency . number_format_i18n( (int) $donation_boosted ) . ' boosted' ); ?></span>
					</span>
				<?php endif; ?>

				<?php if ( $zakat_show && ( $zakat_label_line_1 || $zakat_label_line_2 ) ) : ?>
					<div class="ep-hero__zakat" aria-label="<?php echo esc_attr( trim( $zakat_label_line_1 . ' ' . $zakat_label_line_2 ) ); ?>">
						<?php if ( $zakat_label_line_1 ) : ?>
							<span class="ep-hero__zakat-line"><?php echo esc_html( $zakat_label_line_1 ); ?></span>
						<?php endif; ?>
						<?php if ( $zakat_label_line_2 ) : ?>
							<span class="ep-hero__zakat-line"><?php echo esc_html( $zakat_label_line_2 ); ?></span>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( $cta_label ) : ?>
			<a class="ep-hero__cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>
	</div>

	<?php
	/*
	 * Brown column doubles as the hero photo container. When an `image` is set
	 * we render it as a covering background, drop a darkening gradient on top
	 * (via the --has-image modifier class) so the play button stays legible,
	 * and let the play button sit on top via z-index. When no image is set the
	 * solid conker-2 fallback continues to read as a brand placeholder.
	 */
	$media_classes  = array( 'ep-hero__media' );
	if ( $image ) {
		$media_classes[] = 'ep-hero__media--has-image';
	}
	?>
	<div class="<?php echo esc_attr( implode( ' ', $media_classes ) ); ?>" aria-hidden="<?php echo $image ? 'false' : 'true'; ?>">
		<?php if ( $image ) : ?>
			<img class="ep-hero__media-img"
				src="<?php echo esc_url( $image['sizes']['large'] ?? $image['url'] ); ?>"
				alt="<?php echo esc_attr( $image['alt'] ?? '' ); ?>" />
		<?php endif; ?>

		<?php if ( $video_url ) : ?>
			<a class="ep-hero__play" href="<?php echo esc_url( $video_url ); ?>" aria-label="<?php esc_attr_e( 'Play video', 'everypregnancy' ); ?>">
				<svg viewBox="0 0 24 24" width="32" height="32" focusable="false" aria-hidden="true">
					<path d="M8 5v14l11-7z" fill="currentColor"/>
				</svg>
			</a>
		<?php else: ?>
			<button type="button" class="ep-hero__play ep-hero__play--decorative" aria-label="<?php esc_attr_e( 'Play campaign video', 'everypregnancy' ); ?>" disabled>
				<svg viewBox="0 0 24 24" width="32" height="32" focusable="false" aria-hidden="true">
					<path d="M8 5v14l11-7z" fill="currentColor"/>
				</svg>
			</button>
		<?php endif; ?>
	</div>
</section>
