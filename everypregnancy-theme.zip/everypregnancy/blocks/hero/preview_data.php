<?php
/**
 * Preview content for the Hero block — used in the Gutenberg editor and as
 * fallback in render when fields are empty (so the block always shows
 * something sensible). Source: Figma EveryPregnancy design.
 *
 * @package EveryPregnancy
 */

return array(
	'heading'                      => 'Mothers give us life. Now it’s time to do all we can for mama.',
	'subhead'                      => 'Join the For Mama Challenge to save lives and deliver hope this Ramadan.',
	'body'                         => "<p>800 women die everyday due to complications in pregnancy or childbirth. Without their moms, babies only have a 37% chance of making it to their first birthday.</p>\n<p><strong>Donate now</strong> and together we can create a world where every pregnancy is safe. Every $3 you give will be boosted an additional $1 to amplify the impact of your generosity.</p>",
	'cta_label'                    => 'Donate Now',
	'cta_url'                      => '#donate',
	'video_url'                    => '',
	'image'                        => null,
	'donation_show'                => true,
	'donation_last_donation_label' => 'Last donation 19m ago',
	'donation_donor_count'         => 145,
	'donation_raised'              => 53139,
	'donation_goal'                => 100000,
	'donation_boosted'             => 17713,
	'donation_currency'            => '$',
	'zakat_show'                   => true,
	'zakat_label_line_1'           => 'ZAKAT',
	'zakat_label_line_2'           => 'ELIGIBLE',
);
