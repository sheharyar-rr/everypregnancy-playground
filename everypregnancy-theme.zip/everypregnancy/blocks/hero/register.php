<?php
/**
 * Hero ACF block registration.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

acf_register_block_type( array(
	'name'              => 'everypregnancy-hero',
	'title'             => __( 'Hero — For Mama', 'everypregnancy' ),
	'description'       => __( 'Two-column hero with copy + CTA on the left and a brand image area with a video play button on the right.', 'everypregnancy' ),
	'category'          => 'theme',
	'icon'              => 'cover-image',
	'keywords'          => array( 'hero', 'banner', 'cta' ),
	'mode'              => 'preview',
	'supports'          => array(
		'align'    => false,
		'mode'     => false,
		'jsx'      => true,
		'anchor'   => true,
	),
	'render_template'   => 'blocks/hero/hero.php',
	'enqueue_style'     => get_template_directory_uri() . '/blocks/hero/hero.css',
	'example'           => array(
		'attributes' => array(
			'mode' => 'preview',
			'data' => require __DIR__ . '/preview_data.php',
		),
	),
) );
