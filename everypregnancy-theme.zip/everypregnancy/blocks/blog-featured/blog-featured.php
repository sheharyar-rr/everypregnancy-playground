<?php
/**
 * Blog Featured — large promo card at the top of the Blogs listing page.
 *
 * Lays inside an off-white wrapper card with a stone tag pill, walnut
 * heading, cocoa avatar + author meta row, and a cocoa READ NOW button.
 * Tokens map to design-tokens.json (Figma node 6747:31922).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tag       = get_field( 'tag' );
$heading   = get_field( 'heading' );
$author    = get_field( 'author' );
$date      = get_field( 'date' );
$cta_label = get_field( 'cta_label' );
$cta_url   = get_field( 'cta_url' );

$preview = require __DIR__ . '/preview_data.php';

if ( ! empty( $is_preview ) ) {
	$tag       = $tag       ?: $preview['tag'];
	$heading   = $heading   ?: $preview['heading'];
	$author    = $author    ?: $preview['author'];
	$date      = $date      ?: $preview['date'];
	$cta_label = $cta_label ?: $preview['cta_label'];
}

// Always fall back so the block renders even on freshly inserted instances.
$tag       = $tag       ?: $preview['tag'];
$heading   = $heading   ?: $preview['heading'];
$author    = $author    ?: $preview['author'];
$date      = $date      ?: $preview['date'];
$cta_label = $cta_label ?: $preview['cta_label'];
$cta_url   = $cta_url   ?: $preview['cta_url'];

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'blog-featured-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-blog-featured">
	<article class="ep-blog-featured__card">
		<header class="ep-blog-featured__heading">
			<?php if ( $tag ) : ?>
				<span class="ep-blog-featured__tag"><?php echo esc_html( $tag ); ?></span>
			<?php endif; ?>
			<?php if ( $heading ) : ?>
				<h1 class="ep-blog-featured__title"><?php echo esc_html( $heading ); ?></h1>
			<?php endif; ?>
		</header>

		<div class="ep-blog-featured__meta">
			<div class="ep-blog-featured__author">
				<span class="ep-blog-featured__avatar" aria-hidden="true"></span>
				<?php if ( $author ) : ?>
					<span class="ep-blog-featured__author-name"><?php echo esc_html( $author ); ?></span>
				<?php endif; ?>
			</div>
			<?php if ( $date ) : ?>
				<time class="ep-blog-featured__date"><?php echo esc_html( $date ); ?></time>
			<?php endif; ?>
		</div>

		<?php if ( $cta_label ) : ?>
			<a class="ep-blog-featured__cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>
	</article>
</section>
