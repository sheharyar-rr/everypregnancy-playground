<?php
/**
 * Preview content for the Blog Featured block — used in the Gutenberg editor
 * and as a fallback in the renderer when fields are empty so the block always
 * shows something sensible. Source: Figma EveryPregnancy design (node
 * 6747:31922).
 *
 * @package EveryPregnancy
 */

return array(
	'tag'        => 'Crowdfunding tips',
	'heading'    => "Empowering Mothers Worldwide: Every Pregnancy's Mission and Impact",
	'author'     => 'Every Pregnancy',
	'date'       => 'August 20, 2022',
	'cta_label'  => 'Read Now',
	'cta_url'    => '#',
);
