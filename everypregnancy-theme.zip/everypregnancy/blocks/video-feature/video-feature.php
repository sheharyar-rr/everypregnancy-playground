<?php
/**
 * Video Feature — full-bleed brown section with heading + video thumbnail.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading   = get_field( 'heading' );
$video_url = get_field( 'video_url' );
$image     = get_field( 'image' );

$preview_defaults = require __DIR__ . '/preview_data.php';

if ( ! empty( $is_preview ) || ! $heading ) {
	$heading = $heading ?: $preview_defaults['heading'];
}

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'video-feature-' . ( $block['id'] ?? wp_unique_id() );

$has_image = is_array( $image ) && ! empty( $image['url'] );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-video-feature">
	<div class="ep-video-feature__inner">
		<?php if ( $heading ) : ?>
			<h2 class="ep-video-feature__heading"><?php echo esc_html( $heading ); ?></h2>
		<?php endif; ?>

		<?php
		$wrap_tag   = $video_url ? 'a' : 'div';
		$wrap_attrs = $video_url ? ' href="' . esc_url( $video_url ) . '" aria-label="' . esc_attr__( 'Play video', 'everypregnancy' ) . '"' : '';
		?>
		<<?php echo $wrap_tag; ?> class="ep-video-feature__player<?php echo $has_image ? ' ep-video-feature__player--has-image' : ''; ?>"<?php echo $wrap_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?>>
			<?php if ( $has_image ) : ?>
				<img class="ep-video-feature__media"
					src="<?php echo esc_url( $image['sizes']['large'] ?? $image['url'] ); ?>"
					alt="<?php echo esc_attr( $image['alt'] ?? '' ); ?>" />
			<?php endif; ?>
			<span class="ep-video-feature__overlay" aria-hidden="true"></span>
			<span class="ep-video-feature__play" aria-hidden="true">
				<svg viewBox="0 0 32 32" width="28" height="28" focusable="false" aria-hidden="true">
					<path d="M11 7v18l16-9z" fill="currentColor"/>
				</svg>
			</span>
		</<?php echo $wrap_tag; ?>>
	</div>
</section>
