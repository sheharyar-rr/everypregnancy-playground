<?php
/**
 * Preview content for the Video Feature block. Source: Figma EveryPregnancy
 * Partner Landing Page (frame 6729:27997).
 *
 * @package EveryPregnancy
 */

return array(
	'heading'   => 'How are our partners making a difference?',
	'video_url' => '',
	'image'     => null,
);
