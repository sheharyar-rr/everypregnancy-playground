<?php
/**
 * Editor preview defaults for the Partner Feature Row block.
 *
 * @package EveryPregnancy
 */

return array(
	'heading'           => 'Learn more about our partners in Pakistan',
	'partner_1_name'    => 'Global Alliance for Mom & Baby',
	'partner_1_brand'   => 'Brand SOS',
	'partner_1_profile_label' => 'Brand profile',
	'partner_1_profile_url'   => '#',
	'partner_1_donate_label'  => 'Donate Now',
	'partner_1_donate_url'    => '#donate',
	'partner_2_name'    => 'VITAL Pakistan Trust',
	'partner_2_brand'   => 'Brand',
	'partner_2_profile_label' => 'Brand profile',
	'partner_2_profile_url'   => '#',
	'partner_2_donate_label'  => 'Donate Now',
	'partner_2_donate_url'    => '#donate',
);
