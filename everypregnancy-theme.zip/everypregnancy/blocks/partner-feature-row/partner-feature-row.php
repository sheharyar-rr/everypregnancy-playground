<?php
/**
 * Partner Feature Row.
 *
 * Dark conker-2 background. Heading on top, two cream cards side-by-side.
 * Each card: circular logo placeholder, partner name, brand label, profile
 * button (brown), donate link (brown text). Used on the Pakistan Pledge page
 * (Figma node 6729:21012).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading = get_field( 'heading' );

$partners = array(
	array(
		'name'          => get_field( 'partner_1_name' ),
		'brand'         => get_field( 'partner_1_brand' ),
		'profile_label' => get_field( 'partner_1_profile_label' ),
		'profile_url'   => get_field( 'partner_1_profile_url' ),
		'donate_label'  => get_field( 'partner_1_donate_label' ),
		'donate_url'    => get_field( 'partner_1_donate_url' ),
		'logo'          => get_field( 'partner_1_logo' ),
	),
	array(
		'name'          => get_field( 'partner_2_name' ),
		'brand'         => get_field( 'partner_2_brand' ),
		'profile_label' => get_field( 'partner_2_profile_label' ),
		'profile_url'   => get_field( 'partner_2_profile_url' ),
		'donate_label'  => get_field( 'partner_2_donate_label' ),
		'donate_url'    => get_field( 'partner_2_donate_url' ),
		'logo'          => get_field( 'partner_2_logo' ),
	),
);

// Editor preview fallbacks.
$preview = require __DIR__ . '/preview_data.php';
if ( ! empty( $is_preview ) ) {
	$heading = $heading ?: $preview['heading'];
}

// Per-partner fallbacks so editor previews render even with empty fields.
$partner_defaults = array(
	0 => array(
		'name'          => $preview['partner_1_name'],
		'brand'         => $preview['partner_1_brand'],
		'profile_label' => $preview['partner_1_profile_label'],
		'profile_url'   => $preview['partner_1_profile_url'],
		'donate_label'  => $preview['partner_1_donate_label'],
		'donate_url'    => $preview['partner_1_donate_url'],
	),
	1 => array(
		'name'          => $preview['partner_2_name'],
		'brand'         => $preview['partner_2_brand'],
		'profile_label' => $preview['partner_2_profile_label'],
		'profile_url'   => $preview['partner_2_profile_url'],
		'donate_label'  => $preview['partner_2_donate_label'],
		'donate_url'    => $preview['partner_2_donate_url'],
	),
);
foreach ( $partners as $i => $partner ) {
	foreach ( array( 'name', 'brand', 'profile_label', 'profile_url', 'donate_label', 'donate_url' ) as $k ) {
		if ( empty( $partner[ $k ] ) && ! empty( $is_preview ) ) {
			$partners[ $i ][ $k ] = $partner_defaults[ $i ][ $k ];
		}
	}
}

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'partner-feature-row-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-partner-feature-row">
	<div class="ep-partner-feature-row__inner">

		<?php if ( $heading ) : ?>
			<h2 class="ep-partner-feature-row__heading"><?php echo esc_html( $heading ); ?></h2>
		<?php endif; ?>

		<div class="ep-partner-feature-row__grid">
			<?php foreach ( $partners as $partner ) : ?>
				<?php if ( empty( $partner['name'] ) ) { continue; } ?>
				<article class="ep-partner-feature-row__card">

					<div class="ep-partner-feature-row__logo" aria-hidden="<?php echo $partner['logo'] ? 'false' : 'true'; ?>">
						<?php if ( is_array( $partner['logo'] ) && ! empty( $partner['logo']['url'] ) ) : ?>
							<img src="<?php echo esc_url( $partner['logo']['sizes']['medium'] ?? $partner['logo']['url'] ); ?>"
								alt="<?php echo esc_attr( $partner['logo']['alt'] ?? $partner['name'] ); ?>" />
						<?php else : ?>
							<span class="ep-partner-feature-row__logo-fallback"><?php echo esc_html( $partner['name'] ); ?></span>
						<?php endif; ?>
					</div>

					<?php if ( ! empty( $partner['brand'] ) ) : ?>
						<p class="ep-partner-feature-row__brand"><?php echo esc_html( $partner['brand'] ); ?></p>
					<?php endif; ?>

					<div class="ep-partner-feature-row__actions">
						<?php if ( ! empty( $partner['profile_label'] ) ) : ?>
							<a class="ep-partner-feature-row__btn"
								href="<?php echo esc_url( $partner['profile_url'] ?: '#' ); ?>">
								<?php echo esc_html( $partner['profile_label'] ); ?>
							</a>
						<?php endif; ?>
						<?php if ( ! empty( $partner['donate_label'] ) ) : ?>
							<a class="ep-partner-feature-row__donate"
								href="<?php echo esc_url( $partner['donate_url'] ?: '#donate' ); ?>">
								<?php echo esc_html( $partner['donate_label'] ); ?>
							</a>
						<?php endif; ?>
					</div>

				</article>
			<?php endforeach; ?>
		</div>

	</div>
</section>
