<?php
/**
 * Preview content for the Movement Is Born block — used in the Gutenberg editor
 * and as fallback in the renderer when fields are empty so the block always
 * shows something sensible. Source: Figma EveryPregnancy design (node 6729:1460).
 *
 * @package EveryPregnancy
 */

return array(
	'heading'             => 'A movement is born',
	'heading_script_word' => 'born',
	'body'                => "<p>In 2025, a coalition of faith-inspired philanthropists and donors in the U.S. and U.K. came together with one aim: to raise awareness of the high rates of maternal death around the world. Mid-Atlantic Faith-Inspired Philanthropies, Mothers in Action and Lifelong Lifesavers joined forces to amplify a coordinated outreach campaign asking the world to think about what we owe — and should owe — to \"mama\" to ensure that life-saving interventions reach the mothers and babies who need them.</p>\n<p>Over the course of Ramadan in 2025, For Mama Action Group raised \$13M for maternal health programs and drove thousands of people from more than 175 countries to speak out in solidarity to lend their support and ensure preventable maternal death.</p>\n<p>Building on this success, For Mama has now evolved into Every Pregnancy, a partnership-driven organization poised to continue transforming the state of maternal health care for years to come.</p>",
	'image_main'          => null,
	'image_secondary_1'   => null,
	'image_secondary_2'   => null,
);
