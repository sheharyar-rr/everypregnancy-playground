<?php
/**
 * Movement Is Born — origin story section.
 *
 * Two-column layout: left = heading (with a cursive-script accent on a single
 * word) + a 3-paragraph origin story; right = a 3-image collage of mothers
 * and children. Tokens come from theme.json + the extracted design-tokens.json
 * (Figma → block via Warpspeed pipeline). Figma node 6729:1460.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading             = get_field( 'heading' );
$heading_script_word = get_field( 'heading_script_word' );
$body                = get_field( 'body' );
$image_main          = get_field( 'image_main' );
$image_secondary_1   = get_field( 'image_secondary_1' );
$image_secondary_2   = get_field( 'image_secondary_2' );

// Editor preview fallbacks.
if ( ! empty( $is_preview ) ) {
	$preview = require __DIR__ . '/preview_data.php';
	$heading             = $heading             ?: $preview['heading'];
	$heading_script_word = $heading_script_word ?: $preview['heading_script_word'];
	$body                = $body                ?: $preview['body'];
}

// Bundled fallback photographs (downloaded from Figma node 6729:1460). When an
// ACF image field is populated by an editor, that wins. When it's empty AND
// the bundled file exists on disk, we use the bundled photo. When neither is
// available, the renderer drops a colored placeholder.
$theme_img_dir = get_template_directory() . '/src/img';
$theme_img_uri = get_template_directory_uri() . '/src/img';
$bundled_photos = array(
	'main'        => 'movement-main.png',
	'secondary-1' => 'movement-secondary-1.png',
	'secondary-2' => 'movement-secondary-2.png',
);
$bundled_uri = function ( $key ) use ( $theme_img_dir, $theme_img_uri, $bundled_photos ) {
	$file = $bundled_photos[ $key ] ?? null;
	if ( $file && is_readable( $theme_img_dir . '/' . $file ) ) {
		return $theme_img_uri . '/' . $file;
	}
	return null;
};

// Build the heading markup, wrapping the script word in a span. Case-insensitive,
// whole-word match on the first occurrence only — same approach as safe-promise
// to avoid mangling words like "before" when the script word is "born".
$heading_html = '';
if ( $heading ) {
	$plain = wp_strip_all_tags( $heading );
	if ( $heading_script_word ) {
		$pattern  = '/\b(' . preg_quote( $heading_script_word, '/' ) . ')\b/iu';
		$replaced = preg_replace(
			$pattern,
			'<span class="ep-movement-born__script">$1</span>',
			$plain,
			1,
			$count
		);
		$heading_html = $count ? $replaced : esc_html( $plain );
	} else {
		$heading_html = esc_html( $plain );
	}
}

// Helper: render an <img> from an ACF image array, then a bundled-photo
// fallback, then a colored placeholder as last resort.
$render_collage_image = function ( $image, $modifier, $placeholder_class, $fallback_uri = null, $fallback_alt = '' ) {
	$class = 'ep-movement-born__photo ep-movement-born__photo--' . $modifier;
	if ( is_array( $image ) && ! empty( $image['url'] ) ) {
		$src = $image['sizes']['large'] ?? $image['url'];
		$alt = $image['alt'] ?? '';
		printf(
			'<figure class="%1$s"><img src="%2$s" alt="%3$s" loading="lazy" /></figure>',
			esc_attr( $class ),
			esc_url( $src ),
			esc_attr( $alt )
		);
	} elseif ( $fallback_uri ) {
		printf(
			'<figure class="%1$s"><img src="%2$s" alt="%3$s" loading="lazy" /></figure>',
			esc_attr( $class ),
			esc_url( $fallback_uri ),
			esc_attr( $fallback_alt )
		);
	} else {
		printf(
			'<figure class="%1$s ep-movement-born__photo--placeholder %2$s" aria-hidden="true"></figure>',
			esc_attr( $class ),
			esc_attr( $placeholder_class )
		);
	}
};

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'movement-born-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-movement-born">
	<div class="ep-movement-born__inner">

		<div class="ep-movement-born__text">
			<?php if ( $heading_html ) : ?>
				<h2 class="ep-movement-born__heading">
					<?php
					// $heading_html contains escaped text plus our trusted span wrapper.
					echo wp_kses(
						$heading_html,
						array(
							'span' => array( 'class' => array() ),
							'br'   => array(),
						)
					);
					?>
				</h2>
			<?php endif; ?>

			<?php if ( $body ) : ?>
				<div class="ep-movement-born__body">
					<?php echo wp_kses_post( $body ); ?>
				</div>
			<?php endif; ?>
		</div>

		<div class="ep-movement-born__collage" role="group" aria-label="<?php esc_attr_e( 'Photos of mothers and children', 'everypregnancy' ); ?>">
			<?php
			// Per Figma 6729:1469: two secondary photos sit side-by-side beneath
			// the heading/body text in the left column.
			$render_collage_image(
				$image_secondary_1,
				'secondary-1',
				'ep-movement-born__photo--powder',
				$bundled_uri( 'secondary-1' ),
				__( 'Mother and child at a maternal health center', 'everypregnancy' )
			);
			$render_collage_image(
				$image_secondary_2,
				'secondary-2',
				'ep-movement-born__photo--blush',
				$bundled_uri( 'secondary-2' ),
				__( 'Newborn baby being cared for', 'everypregnancy' )
			);
			?>
		</div>

		<?php
		// Per Figma 6729:1472: the main hero photo lives in its own tall
		// container in the right column at desktop, full-bleed on mobile.
		$render_collage_image(
			$image_main,
			'main',
			'ep-movement-born__photo--conker',
			$bundled_uri( 'main' ),
			__( 'Mother holding her child', 'everypregnancy' )
		);
		?>

	</div>
</section>
