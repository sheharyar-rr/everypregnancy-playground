<?php
/**
 * Preview content for the Mobilization Stats block. Used in the Gutenberg
 * editor and as a fallback in render when fields are empty so the block
 * always shows something sensible. Source: Figma EveryPregnancy design
 * (node 6729:1631).
 *
 * @package EveryPregnancy
 */

return array(
	'eyebrow'      => '',
	'heading'      => '',
	'stat_1_value' => '37 Faith-inspired Organizations',
	'stat_1_body'  => 'across the U.S. and U.K. joined Every Pregnancy during our first year.',
	'stat_2_value' => '$13M Mobilized',
	'stat_2_body'  => "for mothers and babies globally during Every Pregnancy's first charitable giving campaign over Ramadan in 2024.",
	'stat_3_value' => '17 Countries Reached',
	'stat_3_body'  => 'with life-saving interventions benefiting hundreds of women and babies on the frontline of the maternal and newborn health crisis.',
	'stat_4_value' => '50+ Advocates & Community Leaders',
	'stat_4_body'  => "have joined Every Pregnancy's network of champions from diverse fields including health, lifestyle, religious institutions, and more.",
);
