<?php
/**
 * Mobilization Stats — Year One.
 *
 * 2x2 grid of large numeric outcomes on a conker-2 background. Each cell
 * is pure typography — a bold value heading and a body description below,
 * no icons. Tokens map to design-tokens.json.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$eyebrow = get_field( 'eyebrow' );
$heading = get_field( 'heading' );

$stats = array();
for ( $i = 1; $i <= 4; $i++ ) {
	$stats[] = array(
		'value' => get_field( "stat_{$i}_value" ),
		'body'  => get_field( "stat_{$i}_body" ),
	);
}

// Editor preview fallbacks.
if ( ! empty( $is_preview ) ) {
	$preview = require __DIR__ . '/preview_data.php';
	$eyebrow = $eyebrow ?: $preview['eyebrow'];
	$heading = $heading ?: $preview['heading'];
	for ( $i = 1; $i <= 4; $i++ ) {
		$stats[ $i - 1 ]['value'] = $stats[ $i - 1 ]['value'] ?: $preview[ "stat_{$i}_value" ];
		$stats[ $i - 1 ]['body']  = $stats[ $i - 1 ]['body']  ?: $preview[ "stat_{$i}_body" ];
	}
}

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'mobilization-stats-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-mobilization-stats">
	<div class="ep-mobilization-stats__inner">

		<?php if ( $eyebrow || $heading ) : ?>
			<header class="ep-mobilization-stats__header">
				<?php if ( $eyebrow ) : ?>
					<p class="ep-mobilization-stats__eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
				<?php endif; ?>
				<?php if ( $heading ) : ?>
					<h2 class="ep-mobilization-stats__heading"><?php echo wp_kses_post( $heading ); ?></h2>
				<?php endif; ?>
			</header>
		<?php endif; ?>

		<ul class="ep-mobilization-stats__grid" role="list">
			<?php foreach ( $stats as $stat ) :
				if ( empty( $stat['value'] ) && empty( $stat['body'] ) ) {
					continue;
				}
				?>
				<li class="ep-mobilization-stats__item">
					<?php if ( ! empty( $stat['value'] ) ) : ?>
						<p class="ep-mobilization-stats__value"><?php echo esc_html( $stat['value'] ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $stat['body'] ) ) : ?>
						<p class="ep-mobilization-stats__body"><?php echo esc_html( $stat['body'] ); ?></p>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>

	</div>
</section>
