<?php
/**
 * Preview content for the Numbered Steps block. Source: Figma EveryPregnancy
 * Take Action design (node 6747:25118 / 6747:25119).
 *
 * @package EveryPregnancy
 */

return array(
	'heading'        => 'How to Join',
	'step_1_title'   => 'Complete a Short Questionnaire',
	'step_1_body'    => 'Tell us about your organization, maternal and newborn health programs, and focal areas.',
	'step_2_title'   => 'Schedule an Introductory Call',
	'step_2_body'    => 'Meet with our team to explore alignment, answer your questions, and walk through next steps.',
	'step_3_title'   => 'Join Our Coalition',
	'step_3_body'    => 'Officially join by signing a non-binding Memorandum of Understanding and then gain access to coalition tools and opportunities.',
	'cta_heading'    => 'Ready to save the lives of moms and babies everywhere?',
	'cta_label'      => 'Click here to fill out the interest form',
	'cta_url'        => '#interest-form',
);
