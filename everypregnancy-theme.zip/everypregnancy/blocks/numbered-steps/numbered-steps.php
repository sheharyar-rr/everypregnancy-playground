<?php
/**
 * Numbered Steps — How to Join.
 *
 * Powder/blush section with a centered "How to Join" heading, three numbered
 * step cards (cream rounded rectangles with numeric prefix + body), then a
 * closing "Ready to save the lives of moms and babies everywhere?" heading
 * and a brown CTA button to the interest form. Reference Figma node
 * 6747:25118 / 6747:25119.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading     = get_field( 'heading' );
$cta_heading = get_field( 'cta_heading' );
$cta_label   = get_field( 'cta_label' );
$cta_url     = get_field( 'cta_url' );

$steps = array();
for ( $i = 1; $i <= 3; $i++ ) {
	$steps[] = array(
		'title' => get_field( "step_{$i}_title" ),
		'body'  => get_field( "step_{$i}_body" ),
	);
}

if ( ! empty( $is_preview ) ) {
	$preview     = require __DIR__ . '/preview_data.php';
	$heading     = $heading     ?: $preview['heading'];
	$cta_heading = $cta_heading ?: $preview['cta_heading'];
	$cta_label   = $cta_label   ?: $preview['cta_label'];
	$cta_url     = $cta_url     ?: $preview['cta_url'];
	for ( $i = 1; $i <= 3; $i++ ) {
		$steps[ $i - 1 ]['title'] = $steps[ $i - 1 ]['title'] ?: $preview[ "step_{$i}_title" ];
		$steps[ $i - 1 ]['body']  = $steps[ $i - 1 ]['body']  ?: $preview[ "step_{$i}_body" ];
	}
}

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'numbered-steps-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-numbered-steps">
	<div class="ep-numbered-steps__decoration ep-numbered-steps__decoration--left" aria-hidden="true">
		<span class="ep-numbered-steps__shape ep-numbered-steps__shape--cream"></span>
		<span class="ep-numbered-steps__shape ep-numbered-steps__shape--brown"></span>
	</div>
	<div class="ep-numbered-steps__decoration ep-numbered-steps__decoration--right" aria-hidden="true">
		<span class="ep-numbered-steps__shape ep-numbered-steps__shape--cream"></span>
		<span class="ep-numbered-steps__shape ep-numbered-steps__shape--brown"></span>
	</div>

	<div class="ep-numbered-steps__inner">

		<?php if ( $heading ) : ?>
			<h2 class="ep-numbered-steps__heading"><?php echo esc_html( $heading ); ?></h2>
		<?php endif; ?>

		<ol class="ep-numbered-steps__list">
			<?php foreach ( $steps as $idx => $step ) :
				if ( empty( $step['title'] ) && empty( $step['body'] ) ) {
					continue;
				}
				$num = $idx + 1;
				?>
				<li class="ep-numbered-steps__item">
					<p class="ep-numbered-steps__item-title">
						<span class="ep-numbered-steps__item-num"><?php echo esc_html( $num ); ?>.</span>
						<?php echo esc_html( $step['title'] ); ?>
					</p>
					<?php if ( ! empty( $step['body'] ) ) : ?>
						<p class="ep-numbered-steps__item-body"><?php echo esc_html( $step['body'] ); ?></p>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>

		<?php if ( $cta_heading ) : ?>
			<h3 class="ep-numbered-steps__cta-heading"><?php echo esc_html( $cta_heading ); ?></h3>
		<?php endif; ?>

		<?php if ( $cta_label ) : ?>
			<a class="ep-numbered-steps__cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>

	</div>
</section>
