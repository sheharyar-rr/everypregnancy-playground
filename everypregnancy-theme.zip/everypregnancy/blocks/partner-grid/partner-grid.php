<?php
/**
 * Partner Grid — partner directory section.
 *
 * Renders a heading + search bar header, then a 5-column grid of partner
 * organization cards (logo, name, profile + donate links). Cards are
 * hard-coded from preview_data.php for the demo (ACF FREE has no repeater).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading            = get_field( 'heading' );
$subhead            = get_field( 'subhead' );
$search_placeholder = get_field( 'search_placeholder' );

$preview_defaults = require __DIR__ . '/preview_data.php';

$heading            = $heading            ?: $preview_defaults['heading'];
$subhead            = $subhead            ?: $preview_defaults['subhead'];
$search_placeholder = $search_placeholder ?: $preview_defaults['search_placeholder'];
$cards              = $preview_defaults['cards'];

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'partner-grid-' . ( $block['id'] ?? wp_unique_id() );

// Inline SVG for the "drop" placeholder logo (matches Figma's circular logo slot).
$placeholder_svg = '<svg viewBox="0 0 32 32" width="28" height="28" focusable="false" aria-hidden="true">'
	. '<path fill="currentColor" d="M16 3c-3.5 5-8 10.2-8 14.5a8 8 0 0 0 16 0C24 13.2 19.5 8 16 3z"/>'
	. '</svg>';

// Inline SVG for the "Oxfam"-style real-logo mark (decorative leaf + wordmark text rendered as text).
$oxfam_svg = '<svg viewBox="0 0 36 24" width="36" height="24" focusable="false" aria-hidden="true">'
	. '<path fill="#3aaa1c" d="M18 2c-5 4-7 8-7 11a6 6 0 0 0 12 0c0-3-2-7-7-11z"/>'
	. '<path fill="#3aaa1c" d="M11 13c2 0 5 2 7 6-3 1-7-1-8-3-1-2 0-3 1-3z"/>'
	. '</svg>';
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-partner-grid">
	<div class="ep-partner-grid__inner">
		<header class="ep-partner-grid__header">
			<div class="ep-partner-grid__intro">
				<?php if ( $heading ) : ?>
					<h2 class="ep-partner-grid__heading"><?php echo esc_html( $heading ); ?></h2>
				<?php endif; ?>
				<?php if ( $subhead ) : ?>
					<p class="ep-partner-grid__subhead"><?php echo esc_html( $subhead ); ?></p>
				<?php endif; ?>
			</div>

			<form class="ep-partner-grid__search" role="search" onsubmit="return false;">
				<label class="ep-partner-grid__search-label" for="<?php echo esc_attr( $block_id ); ?>-q">
					<span class="screen-reader-text"><?php esc_html_e( 'Search partners', 'everypregnancy' ); ?></span>
				</label>
				<input
					id="<?php echo esc_attr( $block_id ); ?>-q"
					class="ep-partner-grid__search-input"
					type="search"
					name="q"
					placeholder="<?php echo esc_attr( $search_placeholder ); ?>"
					autocomplete="off"
				/>
				<button type="submit" class="ep-partner-grid__search-btn">
					<svg viewBox="0 0 24 24" width="18" height="18" focusable="false" aria-hidden="true">
						<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zm5 12 5 5"/>
					</svg>
					<span><?php esc_html_e( 'Search', 'everypregnancy' ); ?></span>
				</button>
			</form>
		</header>

		<ul class="ep-partner-grid__list" role="list">
			<?php foreach ( $cards as $card ) : ?>
				<?php
				$is_real = ! empty( $card['is_real_logo'] );
				$name    = $card['name'] ?? 'Your Organization';
				$prof    = $card['profile_url'] ?? '#';
				$don     = $card['donate_url'] ?? '#';
				?>
				<li class="ep-partner-grid__card">
					<div class="ep-partner-grid__logo<?php echo $is_real ? ' ep-partner-grid__logo--real' : ''; ?>" aria-hidden="true">
						<?php
						if ( $is_real ) {
							// Single demo real-logo card.
							echo $oxfam_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- inline SVG, hard-coded above.
						} else {
							echo $placeholder_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- inline SVG, hard-coded above.
						}
						?>
					</div>
					<p class="ep-partner-grid__name"><?php echo esc_html( strtoupper( $name ) ); ?></p>
					<a class="ep-partner-grid__profile" href="<?php echo esc_url( $prof ); ?>">
						<?php esc_html_e( 'Go to profile', 'everypregnancy' ); ?>
					</a>
					<a class="ep-partner-grid__donate" href="<?php echo esc_url( $don ); ?>">
						<?php esc_html_e( 'Donate', 'everypregnancy' ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
