<?php
/**
 * Preview content for the Partner Grid block — used in the Gutenberg editor and
 * as fallback in render when ACF fields are empty. Source: Figma EveryPregnancy
 * Partner Landing Page (frame 6729:27371).
 *
 * For the demo we hard-code 25 placeholder cards. The third card (`is_oxfam`)
 * stands in for a real partner logo so the directory shows a mix of real +
 * placeholder slots. Editors can later swap individual cards via ACF if/when
 * the Pro repeater field is available; for the FREE-tier demo we ship the
 * placeholder set.
 *
 * @package EveryPregnancy
 */

$placeholder_card = array(
	'name'         => 'Your Organization',
	'profile_url'  => '#profile',
	'donate_url'   => '#donate',
	'logo'         => '', // empty → renders the powder-circle placeholder
	'is_real_logo' => false,
);

$cards = array_fill( 0, 25, $placeholder_card );

// Drop a single Oxfam-styled card into the grid (Figma shows 3rd column row 1
// using a real logo) so the demo doesn't read as 25 identical placeholders.
$cards[2] = array(
	'name'         => 'Oxfam',
	'profile_url'  => '#profile-oxfam',
	'donate_url'   => '#donate-oxfam',
	'logo'         => '', // we render an inline SVG mark instead of an asset
	'is_real_logo' => true,
);

return array(
	'heading' => 'Partners',
	'subhead' => 'Support your favorite organizations',
	'search_placeholder' => 'Search partners...',
	'cards'   => $cards,
);
