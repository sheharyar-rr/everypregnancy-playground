<?php
/**
 * Staff Grid — Team / Advisory Board.
 *
 * Centered heading on a cream background, followed by a responsive grid of
 * staff cards. Each card is an avatar (left) + name + role (right) sitting
 * inside a stone-colored rounded panel. Used for both "Meet the Team"
 * (12 staff in a 3-column grid) and "Advisory Board" (3 cards in a row).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Read directly from the block's data attribute when available — get_field()
// caches per-block-name in the same request, which corrupts when the same
// block type is used twice on a page (e.g. team + advisory).
$block_data   = ( is_array( $block ) && ! empty( $block['data'] ) ) ? $block['data'] : array();
$heading      = $block_data['heading']      ?? get_field( 'heading' );
$variant      = $block_data['variant']      ?? get_field( 'variant' );
$members_json = $block_data['members_json'] ?? get_field( 'members_json' );
$members      = $block_data['members']      ?? get_field( 'members' );

// Members can come from the repeater (ACF UI) OR from a textarea (block
// markup pre-population — repeaters don't round-trip cleanly through the
// block data attribute, so keep this escape hatch). The textarea accepts
// EITHER:
//   - A JSON array of {name, role, photo} objects
//   - A simple "Name | Role" line per member (one member per line)
if ( ! is_array( $members ) || empty( $members ) ) {
	if ( ! empty( $members_json ) ) {
		$members_json_trimmed = trim( $members_json );
		$decoded = json_decode( $members_json_trimmed, true );
		if ( is_array( $decoded ) ) {
			$members = $decoded;
		} else {
			$members = array();
			$lines = preg_split( '/\r?\n/', $members_json_trimmed );
			foreach ( $lines as $line ) {
				$line = trim( $line );
				if ( '' === $line ) {
					continue;
				}
				$parts = array_map( 'trim', explode( '|', $line ) );
				$members[] = array(
					'name'  => $parts[0] ?? '',
					'role'  => $parts[1] ?? '',
					'photo' => null,
				);
			}
		}
	}
}

if ( ! is_array( $members ) ) {
	$members = array();
}

// Editor preview fallbacks.
if ( ! empty( $is_preview ) && ( empty( $heading ) || empty( $members ) ) ) {
	$preview = require __DIR__ . '/preview_data.php';
	$heading = $heading ?: $preview['heading'];
	$variant = $variant ?: $preview['variant'];
	$members = $members ?: $preview['members'];
}

if ( empty( $variant ) ) {
	$variant = 'team';
}

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'staff-grid-' . ( $block['id'] ?? wp_unique_id() );

$variant_class = 'ep-staff-grid--' . preg_replace( '/[^a-z0-9-]/', '', strtolower( $variant ) );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-staff-grid <?php echo esc_attr( $variant_class ); ?>">
	<div class="ep-staff-grid__inner">

		<?php if ( $heading ) : ?>
			<h2 class="ep-staff-grid__heading"><?php echo esc_html( $heading ); ?></h2>
		<?php endif; ?>

		<?php if ( ! empty( $members ) ) : ?>
			<ul class="ep-staff-grid__list" role="list">
				<?php foreach ( $members as $member ) :
					$name   = $member['name']   ?? '';
					$role   = $member['role']   ?? '';
					$photo  = $member['photo']  ?? null;
					$photo_url = '';
					$photo_alt = '';
					if ( is_array( $photo ) ) {
						$photo_url = $photo['sizes']['thumbnail'] ?? ( $photo['sizes']['medium'] ?? $photo['url'] ?? '' );
						$photo_alt = $photo['alt'] ?? $name;
					}

					if ( empty( $name ) && empty( $role ) ) {
						continue;
					}

					// Initials fallback for empty avatars.
					$initials = '';
					if ( $name ) {
						$parts = preg_split( '/\s+/', wp_strip_all_tags( $name ) );
						foreach ( $parts as $part ) {
							if ( $part !== '' ) {
								$initials .= mb_substr( $part, 0, 1 );
							}
							if ( mb_strlen( $initials ) >= 2 ) {
								break;
							}
						}
						$initials = mb_strtoupper( $initials );
					}
					?>
					<li class="ep-staff-grid__item">
						<div class="ep-staff-grid__avatar" aria-hidden="<?php echo $photo_url ? 'false' : 'true'; ?>">
							<?php if ( $photo_url ) : ?>
								<img class="ep-staff-grid__avatar-img"
									src="<?php echo esc_url( $photo_url ); ?>"
									alt="<?php echo esc_attr( $photo_alt ); ?>" />
							<?php else : ?>
								<span class="ep-staff-grid__avatar-initials"><?php echo esc_html( $initials ); ?></span>
							<?php endif; ?>
						</div>
						<div class="ep-staff-grid__meta">
							<?php if ( $name ) : ?>
								<p class="ep-staff-grid__name"><?php echo esc_html( $name ); ?></p>
							<?php endif; ?>
							<?php if ( $role ) : ?>
								<p class="ep-staff-grid__role"><?php echo esc_html( $role ); ?></p>
							<?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

	</div>
</section>
