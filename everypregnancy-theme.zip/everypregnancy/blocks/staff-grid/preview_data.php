<?php
/**
 * Preview content for the Staff Grid block. Used in the Gutenberg editor and
 * as a fallback in render when fields are empty so the block always shows
 * something sensible. Source: Figma EveryPregnancy About page (node 6747:43681).
 *
 * @package EveryPregnancy
 */

return array(
	'heading' => 'Meet the Team',
	'variant' => 'team',
	'members' => array(
		array(
			'name'  => 'Isra Chaker',
			'role'  => 'Chief Executive Officer',
			'photo' => null,
		),
		array(
			'name'  => 'Marleen Vellekoop',
			'role'  => 'Chief Operations and Strategy Officer',
			'photo' => null,
		),
		array(
			'name'  => 'Adil Ali',
			'role'  => 'Fundraising and Tech Co-Lead, Amanahfy',
			'photo' => null,
		),
	),
);
