<?php
/**
 * Testimonial — Single Quote with Portrait.
 *
 * Renders a stone-cream section with an off-white card. The portrait sits on
 * the left with a domed (semicircle) top and a flat bottom; the quote and
 * attribution sit on the right. Two solid-filled circular slider arrows sit
 * below the card (decorative for now — carousel deferred). Tokens come from
 * theme.json + design-tokens.json. Sourced from Figma node 6729:1916.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$eyebrow            = get_field( 'eyebrow' );
$heading            = get_field( 'heading' );
$quote              = get_field( 'quote' );
$attribution_name   = get_field( 'attribution_name' );
$attribution_role   = get_field( 'attribution_role' );
$portrait           = get_field( 'portrait' );
$show_slider_arrows = get_field( 'show_slider_arrows' );

$preview_defaults = require __DIR__ . '/preview_data.php';

// "Never set" → use defaults (so blocks saved before fields existed still render).
if ( null === $show_slider_arrows ) {
	$show_slider_arrows = $preview_defaults['show_slider_arrows'];
}
if ( null === $quote || '' === $quote ) {
	$quote = $preview_defaults['quote'];
}
if ( null === $attribution_name || '' === $attribution_name ) {
	$attribution_name = $preview_defaults['attribution_name'];
}
if ( null === $attribution_role || '' === $attribution_role ) {
	$attribution_role = $preview_defaults['attribution_role'];
}

if ( ! empty( $is_preview ) ) {
	$eyebrow = $eyebrow ?: $preview_defaults['eyebrow'];
	$heading = $heading ?: $preview_defaults['heading'];
}

// Resolve portrait: ACF image first, then bundled Malika fallback (matches
// the Figma reference photo), then a neutral colored placeholder silhouette.
$portrait_src = '';
$portrait_alt = '';
if ( $portrait && is_array( $portrait ) ) {
	$portrait_src = $portrait['sizes']['large'] ?? $portrait['url'] ?? '';
	$portrait_alt = $portrait['alt'] ?? $attribution_name;
} else {
	$bundled_rel  = '/src/img/testimonial-malika.png';
	$bundled_path = get_template_directory() . $bundled_rel;
	if ( file_exists( $bundled_path ) ) {
		$portrait_src = get_template_directory_uri() . $bundled_rel;
		$portrait_alt = $attribution_name ?: __( 'Testimonial portrait', 'everypregnancy' );
	}
}

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'testimonial-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-testimonial">
	<div class="ep-testimonial__inner">
		<?php if ( $eyebrow || $heading ) : ?>
			<header class="ep-testimonial__header">
				<?php if ( $eyebrow ) : ?>
					<p class="ep-testimonial__eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
				<?php endif; ?>
				<?php if ( $heading ) : ?>
					<h2 class="ep-testimonial__heading"><?php echo wp_kses_post( $heading ); ?></h2>
				<?php endif; ?>
			</header>
		<?php endif; ?>

		<article class="ep-testimonial__card">
			<div class="ep-testimonial__portrait">
				<?php if ( $portrait_src ) : ?>
					<img class="ep-testimonial__portrait-img"
						src="<?php echo esc_url( $portrait_src ); ?>"
						alt="<?php echo esc_attr( $portrait_alt ); ?>" />
				<?php else : ?>
					<div class="ep-testimonial__portrait-placeholder" aria-hidden="true">
						<svg class="ep-testimonial__portrait-svg" viewBox="0 0 200 240" focusable="false" aria-hidden="true">
							<circle cx="100" cy="86" r="42" fill="currentColor" />
							<path d="M28 232c0-44 32-78 72-78s72 34 72 78v8H28v-8z" fill="currentColor" />
						</svg>
					</div>
				<?php endif; ?>
			</div>

			<div class="ep-testimonial__content">
				<blockquote class="ep-testimonial__quote">
					<?php echo wp_kses_post( wpautop( $quote ) ); ?>
				</blockquote>

				<footer class="ep-testimonial__byline">
					<?php if ( $attribution_name ) : ?>
						<p class="ep-testimonial__name"><?php echo esc_html( $attribution_name ); ?></p>
					<?php endif; ?>
					<?php if ( $attribution_role ) : ?>
						<p class="ep-testimonial__role"><?php echo esc_html( $attribution_role ); ?></p>
					<?php endif; ?>
				</footer>
			</div>
		</article>

		<?php if ( $show_slider_arrows ) : ?>
			<div class="ep-testimonial__arrows" role="group" aria-label="<?php esc_attr_e( 'Testimonial navigation', 'everypregnancy' ); ?>">
				<button type="button"
					class="ep-testimonial__arrow ep-testimonial__arrow--prev"
					aria-label="<?php esc_attr_e( 'Previous testimonial', 'everypregnancy' ); ?>"
					disabled>
					<svg viewBox="0 0 40 40" width="40" height="40" focusable="false" aria-hidden="true">
						<path fill="currentColor" d="M20 0l.56.008C31.34.304 40 9.147 40 20c0 11.02-8.96 20-20 20S0 31.02 0 20C0 8.96 8.98 0 20 0zm3.96 12c-.6-.6-1.54-.6-2.12 0l-6.98 6.94a1.5 1.5 0 000 2.12L21.84 28a1.6 1.6 0 001.04.44 1.4 1.4 0 001.08-.44c.58-.6.58-1.54-.02-2.12L18.04 20l5.9-5.88c.6-.58.6-1.54-.02-2.12z"/>
					</svg>
				</button>
				<button type="button"
					class="ep-testimonial__arrow ep-testimonial__arrow--next"
					aria-label="<?php esc_attr_e( 'Next testimonial', 'everypregnancy' ); ?>"
					disabled>
					<svg viewBox="0 0 40 40" width="40" height="40" focusable="false" aria-hidden="true">
						<path fill="currentColor" d="M20 0l.56.008C31.34.304 40 9.147 40 20c0 11.02-8.96 20-20 20S0 31.02 0 20C0 8.96 8.98 0 20 0zm3.96 12c-.6-.6-1.54-.6-2.12 0l-6.98 6.94a1.5 1.5 0 000 2.12L21.84 28a1.6 1.6 0 001.04.44 1.4 1.4 0 001.08-.44c.58-.6.58-1.54-.02-2.12L18.04 20l5.9-5.88c.6-.58.6-1.54-.02-2.12z"/>
					</svg>
				</button>
			</div>
		<?php endif; ?>
	</div>
</section>
