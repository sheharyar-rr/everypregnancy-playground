<?php
/**
 * Preview content for the Testimonial block — used in the Gutenberg editor and
 * as fallback in render when fields are empty so the block always shows
 * something sensible. Source: Figma EveryPregnancy design (node 6729:1916).
 *
 * @package EveryPregnancy
 */

return array(
	'eyebrow'            => '',
	'heading'            => '',
	'quote'              => '"As a mom to twins who just turned one, I\'ve only recently begun to hear the very sweet sounds of someone calling me \'mama\'. It\'s something I don\'t take for granted — knowing that every two minutes a woman dies during pregnancy or childbirth. What gives me hope is also knowing that stat is preventable, and that a campaign like \'For Mama\' is one of the first steps."',
	'attribution_name'   => 'Malika Bilal',
	'attribution_role'   => 'International News Journalist',
	'portrait'           => null,
	'show_slider_arrows' => true,
);
