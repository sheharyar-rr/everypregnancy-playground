<?php
/**
 * Newsletter Signup — For Mama Challenge.
 *
 * Centered signup section with first name + email inputs side by side and a
 * full-width SIGN UP button. Sits on a blush background with cream + brown
 * decorative half-circles on each edge. Tokens come from theme.json + the
 * extracted design-tokens.json (Figma → block via Warpspeed pipeline).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading          = get_field( 'heading' );
$first_name_label = get_field( 'first_name_label' );
$email_label      = get_field( 'email_label' );
$submit_label     = get_field( 'submit_label' );
$form_action      = get_field( 'form_action' );
$success_message  = get_field( 'success_message' );

// Editor preview fallbacks.
if ( ! empty( $is_preview ) ) {
	$preview = require __DIR__ . '/preview_data.php';
	$heading          = $heading          ?: $preview['heading'];
	$first_name_label = $first_name_label ?: $preview['first_name_label'];
	$email_label      = $email_label      ?: $preview['email_label'];
	$submit_label     = $submit_label     ?: $preview['submit_label'];
	$form_action      = $form_action      ?: $preview['form_action'];
	$success_message  = $success_message  ?: $preview['success_message'];
}

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'newsletter-signup-' . ( $block['id'] ?? wp_unique_id() );

$first_name_id = $block_id . '-first-name';
$email_id      = $block_id . '-email';
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-newsletter-signup">
	<div class="ep-newsletter-signup__decoration ep-newsletter-signup__decoration--left" aria-hidden="true">
		<span class="ep-newsletter-signup__shape ep-newsletter-signup__shape--cream"></span>
		<span class="ep-newsletter-signup__shape ep-newsletter-signup__shape--brown"></span>
	</div>
	<div class="ep-newsletter-signup__decoration ep-newsletter-signup__decoration--right" aria-hidden="true">
		<span class="ep-newsletter-signup__shape ep-newsletter-signup__shape--cream"></span>
		<span class="ep-newsletter-signup__shape ep-newsletter-signup__shape--brown"></span>
	</div>

	<div class="ep-newsletter-signup__inner">
		<?php if ( $heading ) : ?>
			<h2 class="ep-newsletter-signup__heading">
				<?php echo wp_kses( $heading, array( 'br' => array() ) ); ?>
			</h2>
		<?php endif; ?>

		<form
			class="ep-newsletter-signup__form"
			method="post"
			action="<?php echo esc_url( $form_action ?: '' ); ?>"
			aria-label="<?php esc_attr_e( 'Newsletter signup', 'everypregnancy' ); ?>"
		>
			<?php wp_nonce_field( 'ep_newsletter', 'ep_newsletter_nonce' ); ?>

			<div class="ep-newsletter-signup__fields">
				<div class="ep-newsletter-signup__field">
					<label class="ep-newsletter-signup__label screen-reader-text" for="<?php echo esc_attr( $first_name_id ); ?>">
						<?php echo esc_html( $first_name_label ); ?>
					</label>
					<input
						class="ep-newsletter-signup__input"
						type="text"
						id="<?php echo esc_attr( $first_name_id ); ?>"
						name="first_name"
						placeholder="<?php echo esc_attr( $first_name_label ); ?>"
						autocomplete="given-name"
						required
					/>
				</div>

				<div class="ep-newsletter-signup__field">
					<label class="ep-newsletter-signup__label screen-reader-text" for="<?php echo esc_attr( $email_id ); ?>">
						<?php echo esc_html( $email_label ); ?>
					</label>
					<input
						class="ep-newsletter-signup__input"
						type="email"
						id="<?php echo esc_attr( $email_id ); ?>"
						name="email"
						placeholder="<?php echo esc_attr( $email_label ); ?>"
						autocomplete="email"
						required
					/>
				</div>
			</div>

			<?php /* Honeypot field — real users leave this empty; bots tend to fill it. */ ?>
			<div class="ep-newsletter-signup__honeypot" aria-hidden="true">
				<label for="<?php echo esc_attr( $block_id ); ?>-website">
					<?php esc_html_e( 'Website', 'everypregnancy' ); ?>
				</label>
				<input
					type="text"
					id="<?php echo esc_attr( $block_id ); ?>-website"
					name="website"
					tabindex="-1"
					autocomplete="off"
					value=""
				/>
			</div>

			<button class="ep-newsletter-signup__submit" type="submit">
				<?php echo esc_html( $submit_label ); ?>
			</button>
		</form>

		<?php if ( $success_message ) : ?>
			<p class="ep-newsletter-signup__success" hidden>
				<?php echo esc_html( $success_message ); ?>
			</p>
		<?php endif; ?>
	</div>
</section>
