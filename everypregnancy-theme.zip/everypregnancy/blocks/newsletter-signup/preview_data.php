<?php
/**
 * Preview content for the Newsletter Signup block — used in the Gutenberg
 * editor and as a fallback in the renderer when fields are empty so the block
 * always shows something sensible. Source: Figma EveryPregnancy design
 * (node 6729:2945).
 *
 * @package EveryPregnancy
 */

return array(
	'heading'          => "Let's take action for Mama. If not us, who else?",
	'first_name_label' => 'First Name',
	'email_label'      => 'Your Email',
	'submit_label'     => 'Sign Up',
	'form_action'      => '',
	'success_message'  => 'Thanks for joining the For Mama Challenge.',
);
