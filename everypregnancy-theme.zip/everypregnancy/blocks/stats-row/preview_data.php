<?php
/**
 * Preview content for the Stats Row block. Used in the Gutenberg editor and
 * as fallback in render when fields are empty so the block always shows
 * something sensible. Source: Figma EveryPregnancy design (node 6729:1435).
 *
 * @package EveryPregnancy
 */

return array(
	'eyebrow'      => '',
	'heading'      => '',
	'stat_1_value' => '2 Minutes',
	'stat_1_body'  => 'Every 2 minutes a woman dies in pregnancy or childbirth.',
	'stat_1_icon'  => null,
	'stat_2_value' => '2x Higher',
	'stat_2_body'  => 'Maternal and infant mortality rates are 2x as high in Muslim-majority countries.',
	'stat_2_icon'  => null,
	'stat_3_value' => '2/3 Deaths',
	'stat_3_body'  => 'Well-trained midwives could help prevent 2/3s of all maternal and newborn deaths.',
	'stat_3_icon'  => null,
	'stat_4_value' => '40% of deaths',
	'stat_4_body'  => 'More than 40% of newborn deaths could be prevented by proven interventions like skilled birth attendance.',
	'stat_4_icon'  => null,
);
