<?php
/**
 * Stats Row — Maternal Health.
 *
 * 2x2 grid of statistics on a conker-2 background. Each stat has an icon
 * (image field, falls back to inline SVG placeholder), a big value heading,
 * and a body description. Tokens map to design-tokens.json.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$eyebrow = get_field( 'eyebrow' );
$heading = get_field( 'heading' );

$stats = array();
for ( $i = 1; $i <= 4; $i++ ) {
	$stats[] = array(
		'value' => get_field( "stat_{$i}_value" ),
		'body'  => get_field( "stat_{$i}_body" ),
		'icon'  => get_field( "stat_{$i}_icon" ),
	);
}

// Editor preview fallbacks
if ( ! empty( $is_preview ) ) {
	$preview = require __DIR__ . '/preview_data.php';
	$eyebrow = $eyebrow ?: $preview['eyebrow'];
	$heading = $heading ?: $preview['heading'];
	for ( $i = 1; $i <= 4; $i++ ) {
		$stats[ $i - 1 ]['value'] = $stats[ $i - 1 ]['value'] ?: $preview[ "stat_{$i}_value" ];
		$stats[ $i - 1 ]['body']  = $stats[ $i - 1 ]['body']  ?: $preview[ "stat_{$i}_body" ];
	}
}

// Bundled icons extracted from Figma node 6729:1435 via Dev Mode MCP.
// Used when the editor hasn't supplied a custom icon for that stat.
// Order matches the Figma stats: 2 Minutes / 2x Higher / 2/3 Deaths / 40% of deaths.
$bundled_icons = array(
	get_template_directory() . '/src/img/stat-1-minutes.png',
	get_template_directory() . '/src/img/stat-icon-a.png',     // clipboard+chart (transparent PNG)
	get_template_directory() . '/src/img/stat-icon-b.png',     // pie chart (transparent PNG)
	get_template_directory() . '/src/img/stat-4-percent.png',
);
$bundled_icons_uri = array(
	get_template_directory_uri() . '/src/img/stat-1-minutes.png',
	get_template_directory_uri() . '/src/img/stat-icon-a.png',
	get_template_directory_uri() . '/src/img/stat-icon-b.png',
	get_template_directory_uri() . '/src/img/stat-4-percent.png',
);

// Inline placeholder SVGs — used when the icon image field is empty AND the
// bundled file isn't on disk. Tight viewBoxes so the glyph fills the wrapper.
// Powder-pink stroke/fill via currentColor, decorative only.
$placeholders = array(
	// 1 — clock face with arrow (2 Minutes)
	'<svg viewBox="0 0 80 100" width="100%" height="100%" focusable="false" aria-hidden="true"><circle cx="40" cy="55" r="32" fill="none" stroke="currentColor" stroke-width="4"/><line x1="40" y1="55" x2="40" y2="34" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><line x1="40" y1="55" x2="56" y2="64" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><rect x="34" y="10" width="12" height="6" rx="2" fill="currentColor"/></svg>',
	// 2 — clipboard with rising chart (2x Higher) — bundled PNG covers this normally
	'<svg viewBox="0 0 80 100" width="100%" height="100%" focusable="false" aria-hidden="true"><rect x="14" y="20" width="52" height="68" rx="4" fill="none" stroke="currentColor" stroke-width="4"/><rect x="28" y="12" width="24" height="12" rx="2" fill="currentColor"/><polyline points="22,72 36,58 46,66 62,42" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/><polyline points="54,42 62,42 62,50" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
	// 3 — pie chart (2/3 Deaths) — bundled PNG covers this normally
	'<svg viewBox="0 0 80 100" width="100%" height="100%" focusable="false" aria-hidden="true"><circle cx="40" cy="50" r="32" fill="currentColor"/><path d="M40 18 A32 32 0 0 1 72 50 L40 50 Z" fill="none" stroke="#601f0b" stroke-width="6"/></svg>',
	// 4 — mother holding baby silhouette (40% of deaths)
	'<svg viewBox="0 0 80 100" width="100%" height="100%" focusable="false" aria-hidden="true"><circle cx="34" cy="22" r="9" fill="currentColor"/><path d="M14 88 C14 60 22 42 34 42 C46 42 54 60 54 88 Z" fill="currentColor"/><circle cx="50" cy="48" r="6" fill="#601f0b"/><path d="M44 64 C44 56 47 52 50 52 C53 52 56 56 56 64 Z" fill="#601f0b"/><circle cx="50" cy="48" r="5.5" fill="currentColor"/><path d="M44.5 64 C44.5 57 47 53 50 53 C53 53 55.5 57 55.5 64 Z" fill="currentColor"/></svg>',
);

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'stats-row-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-stats-row">
	<div class="ep-stats-row__inner">

		<?php if ( $eyebrow || $heading ) : ?>
			<header class="ep-stats-row__header">
				<?php if ( $eyebrow ) : ?>
					<p class="ep-stats-row__eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
				<?php endif; ?>
				<?php if ( $heading ) : ?>
					<h2 class="ep-stats-row__heading"><?php echo wp_kses_post( $heading ); ?></h2>
				<?php endif; ?>
			</header>
		<?php endif; ?>

		<ul class="ep-stats-row__grid" role="list">
			<?php foreach ( $stats as $idx => $stat ) :
				if ( empty( $stat['value'] ) && empty( $stat['body'] ) ) {
					continue;
				}
				?>
				<li class="ep-stats-row__item">
					<div class="ep-stats-row__icon" aria-hidden="true">
						<?php if ( ! empty( $stat['icon'] ) && is_array( $stat['icon'] ) ) : ?>
							<img
								src="<?php echo esc_url( $stat['icon']['sizes']['thumbnail'] ?? $stat['icon']['url'] ); ?>"
								alt=""
								loading="lazy"
								decoding="async"
							/>
						<?php elseif ( isset( $bundled_icons[ $idx ] ) && file_exists( $bundled_icons[ $idx ] ) ) : ?>
							<img
								src="<?php echo esc_url( $bundled_icons_uri[ $idx ] ); ?>"
								alt=""
								loading="lazy"
								decoding="async"
							/>
						<?php else : ?>
							<?php echo $placeholders[ $idx ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php endif; ?>
					</div>
					<div class="ep-stats-row__copy">
						<?php if ( ! empty( $stat['value'] ) ) : ?>
							<p class="ep-stats-row__value"><?php echo esc_html( $stat['value'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $stat['body'] ) ) : ?>
							<p class="ep-stats-row__body"><?php echo esc_html( $stat['body'] ); ?></p>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>

	</div>
</section>
