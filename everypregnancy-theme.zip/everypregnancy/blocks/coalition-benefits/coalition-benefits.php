<?php
/**
 * Coalition Benefits — Why Join the Coalition?
 *
 * Dark conker-2 section with a centered intro paragraph followed by a 2-column
 * grid of six benefits. Each benefit row pairs a small icon (decorative
 * inline SVG) with a title + body. Tokens map to design-tokens.json.
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$heading    = get_field( 'heading' );
$intro      = get_field( 'intro' );
$list_label = get_field( 'list_label' );

$benefits = array();
for ( $i = 1; $i <= 6; $i++ ) {
	$benefits[] = array(
		'title' => get_field( "benefit_{$i}_title" ),
		'body'  => get_field( "benefit_{$i}_body" ),
	);
}

if ( ! empty( $is_preview ) ) {
	$preview    = require __DIR__ . '/preview_data.php';
	$heading    = $heading    ?: $preview['heading'];
	$intro      = $intro      ?: $preview['intro'];
	$list_label = $list_label ?: $preview['list_label'];
	for ( $i = 1; $i <= 6; $i++ ) {
		$benefits[ $i - 1 ]['title'] = $benefits[ $i - 1 ]['title'] ?: $preview[ "benefit_{$i}_title" ];
		$benefits[ $i - 1 ]['body']  = $benefits[ $i - 1 ]['body']  ?: $preview[ "benefit_{$i}_body" ];
	}
}

$block_id = ! empty( $block['anchor'] ) ? $block['anchor'] : 'coalition-benefits-' . ( $block['id'] ?? wp_unique_id() );

// Decorative icon — small starburst/accent in blush. Inline so it always paints,
// regardless of asset bundling. Uses currentColor so the parent's color rules.
$icon_svg = '<svg class="ep-coalition-benefits__icon" viewBox="0 0 32 32" width="32" height="32" focusable="false" aria-hidden="true"><path fill="currentColor" d="M16 2.4 19.2 11l8.8 1.6-6.6 6 1.6 8.8L16 23.2 9 27.4l1.6-8.8-6.6-6L12.8 11z"/></svg>';
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-coalition-benefits">
	<div class="ep-coalition-benefits__inner">

		<header class="ep-coalition-benefits__header">
			<?php if ( $heading ) : ?>
				<h2 class="ep-coalition-benefits__heading"><?php echo esc_html( $heading ); ?></h2>
			<?php endif; ?>
			<?php if ( $intro ) : ?>
				<p class="ep-coalition-benefits__intro"><?php echo esc_html( $intro ); ?></p>
			<?php endif; ?>
			<?php if ( $list_label ) : ?>
				<p class="ep-coalition-benefits__list-label"><?php echo esc_html( $list_label ); ?></p>
			<?php endif; ?>
		</header>

		<ul class="ep-coalition-benefits__grid" role="list">
			<?php foreach ( $benefits as $benefit ) :
				if ( empty( $benefit['title'] ) && empty( $benefit['body'] ) ) {
					continue;
				}
				?>
				<li class="ep-coalition-benefits__item">
					<div class="ep-coalition-benefits__item-icon" aria-hidden="true">
						<?php echo $icon_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — static SVG. ?>
					</div>
					<div class="ep-coalition-benefits__item-text">
						<?php if ( ! empty( $benefit['title'] ) ) : ?>
							<p class="ep-coalition-benefits__item-title"><?php echo esc_html( $benefit['title'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $benefit['body'] ) ) : ?>
							<p class="ep-coalition-benefits__item-body"><?php echo esc_html( $benefit['body'] ); ?></p>
						<?php endif; ?>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>

	</div>
</section>
