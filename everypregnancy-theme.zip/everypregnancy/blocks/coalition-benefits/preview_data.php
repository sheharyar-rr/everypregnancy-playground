<?php
/**
 * Preview content for the Coalition Benefits block. Used in the Gutenberg
 * editor and as a fallback in render when fields are empty so the block
 * always shows something sensible. Source: Figma EveryPregnancy Take Action
 * design (node 6747:25062 / 6747:25071).
 *
 * @package EveryPregnancy
 */

return array(
	'heading'      => 'Why Join the Coalition?',
	'intro'        => 'When you become part of the Every Pregnancy Coalition, you gain access to a powerful platform designed to elevate your impact and catalyze change. Rooted in shared values and inspired by faith, our coalition unites Muslim-led and faith-inspired organizations with a shared commitment to make every pregnancy safe.',
	'list_label'   => 'Coalition members benefit from:',
	'benefit_1_title' => 'Match Funding Opportunities',
	'benefit_1_body'  => 'Unlock co-funding to scale your maternal and newborn health programs to reach more mothers and babies.',
	'benefit_2_title' => 'Access to the Latest Technology',
	'benefit_2_body'  => 'Collaborate with our resource partners to bring cutting-edge health solutions to the frontlines of your work.',
	'benefit_3_title' => 'Support for Data & Impact Measurement',
	'benefit_3_body'  => 'Increase visibility of your impact by joining a coalition that combines metrics and demonstrates the power of collective action for mothers and babies at scale.',
	'benefit_4_title' => 'Country-Based Coordination & Collaboration',
	'benefit_4_body'  => 'Work side by side with other partners in-country to share learning, align strategies, and bolster the collective impact on mothers and babies.',
	'benefit_5_title' => 'Amplified Voice & Visibility',
	'benefit_5_body'  => 'Access tailored campaign, communication, and content support to showcase your work. Leverage a powerful network of champions and influencers to expand your reach and ensure underrepresented voices shape conversations at every level.',
	'benefit_6_title' => 'Technical Support',
	'benefit_6_body'  => 'Receive guidance on aligning maternal and newborn health interventions with global best practices and evidence-informed solutions.',
);
