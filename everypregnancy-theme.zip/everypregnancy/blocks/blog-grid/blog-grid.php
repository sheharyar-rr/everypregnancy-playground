<?php
/**
 * Blog Grid — Categories filter + 3-column blog cards.
 *
 * Renders the cream "Partner Landing Page" section from the Blogs page:
 * a left-aligned "Categories" heading, a row of blush pill filter buttons,
 * and a 3-column responsive grid of blog cards. Card content is hardcoded
 * via preview_data.php for the demo (FREE-compatible, no ACF repeater).
 * Editors can still customise the section heading and category labels.
 *
 * Tokens map to design-tokens.json (Figma node 6747:31933).
 *
 * @package EveryPregnancy
 *
 * @var array $block      The full block array.
 * @var bool  $is_preview Whether the block is rendering in the editor.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$preview = require __DIR__ . '/preview_data.php';

$heading       = get_field( 'heading' );
$categories_in = get_field( 'categories' );

$heading = $heading ?: $preview['heading'];

// Categories — accept newline-separated text from the textarea, fall back to
// preview defaults when empty so the block always renders the full filter row.
$categories = array();
if ( is_string( $categories_in ) && '' !== trim( $categories_in ) ) {
	$lines      = preg_split( '/\r\n|\r|\n/', $categories_in );
	$categories = array_values( array_filter( array_map( 'trim', $lines ) ) );
}
if ( empty( $categories ) ) {
	$categories = $preview['categories'];
}

// Cards — hardcoded for the demo (FREE-compatible, no ACF repeater).
$cards = $preview['cards'];

$block_id = ! empty( $block['anchor'] )
	? $block['anchor']
	: 'blog-grid-' . ( $block['id'] ?? wp_unique_id() );
?>
<section id="<?php echo esc_attr( $block_id ); ?>" class="ep-blog-grid">
	<div class="ep-blog-grid__inner">

		<header class="ep-blog-grid__header">
			<?php if ( $heading ) : ?>
				<h2 class="ep-blog-grid__heading"><?php echo esc_html( $heading ); ?></h2>
			<?php endif; ?>

			<?php if ( ! empty( $categories ) ) : ?>
				<ul class="ep-blog-grid__categories" role="list">
					<?php foreach ( $categories as $category ) : ?>
						<li class="ep-blog-grid__category-item">
							<button type="button" class="ep-blog-grid__category">
								<?php echo esc_html( $category ); ?>
							</button>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</header>

		<ul class="ep-blog-grid__cards" role="list">
			<?php foreach ( $cards as $card ) :
				$tone_class = ! empty( $card['image_tone'] ) ? 'ep-blog-grid__media--' . $card['image_tone'] : '';
				?>
				<li class="ep-blog-grid__item">
					<article class="ep-blog-grid__card">
						<a class="ep-blog-grid__link" href="<?php echo esc_url( $card['url'] ?: '#' ); ?>">
							<div class="ep-blog-grid__media <?php echo esc_attr( $tone_class ); ?>" aria-hidden="true">
								<?php if ( ! empty( $card['image'] ) ) : ?>
									<img class="ep-blog-grid__media-img"
										src="<?php echo esc_url( $card['image'] ); ?>"
										alt=""
										loading="lazy"
										decoding="async" />
								<?php endif; ?>
							</div>

							<div class="ep-blog-grid__body">
								<header class="ep-blog-grid__card-heading">
									<?php if ( ! empty( $card['tag'] ) ) : ?>
										<span class="ep-blog-grid__tag"><?php echo esc_html( $card['tag'] ); ?></span>
									<?php endif; ?>
									<?php if ( ! empty( $card['heading'] ) ) : ?>
										<h3 class="ep-blog-grid__title"><?php echo esc_html( $card['heading'] ); ?></h3>
									<?php endif; ?>
								</header>

								<div class="ep-blog-grid__meta">
									<div class="ep-blog-grid__author">
										<span class="ep-blog-grid__avatar" aria-hidden="true"></span>
										<?php if ( ! empty( $card['author'] ) ) : ?>
											<span class="ep-blog-grid__author-name"><?php echo esc_html( $card['author'] ); ?></span>
										<?php endif; ?>
									</div>
									<?php if ( ! empty( $card['date'] ) ) : ?>
										<time class="ep-blog-grid__date"><?php echo esc_html( $card['date'] ); ?></time>
									<?php endif; ?>
								</div>
							</div>
						</a>
					</article>
				</li>
			<?php endforeach; ?>
		</ul>

	</div>
</section>
