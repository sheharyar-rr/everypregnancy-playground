<?php
/**
 * Preview content for the Blog Grid block — also used as the canonical card
 * dataset (this block's content is hardcoded for the demo, ACF only exposes
 * the heading + categories list). Source: Figma EveryPregnancy design
 * (node 6747:31933 — ForMama Blogs Ver 2 grid).
 *
 * @package EveryPregnancy
 */

return array(
	'heading'    => 'Categories',
	'categories' => array(
		'Crowdfunding tips',
		'For Mama Tips',
		'Zakat',
		'Charity',
		'Ramadan',
		'How To Give',
		'Kids',
	),
	'cards'      => array(
		array(
			'tag'        => 'Crowdfunding tips',
			'heading'    => "Empowering Mothers Worldwide: Every Pregnancy's Mission and Impact",
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'pink',
			'url'        => '#',
		),
		array(
			'tag'        => 'Every Pregnancy Tips',
			'heading'    => 'Supporting Muslim Mothers: How Every Pregnancy Makes a Difference',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'cocoa',
			'url'        => '#',
		),
		array(
			'tag'        => 'Zakat',
			'heading'    => 'Every Pregnancy: A Beacon of Hope for Mothers in Need Around The World.',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'pink',
			'url'        => '#',
		),
		array(
			'tag'        => 'Charity',
			'heading'    => 'Uniting for a Cause: How Donations to Every Pregnancy Transform Lives',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'pink',
			'url'        => '#',
		),
		array(
			'tag'        => 'Charity',
			'heading'    => 'Every Pregnancy: Strengthening Communities by Empowering Mothers',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'cocoa',
			'url'        => '#',
		),
		array(
			'tag'        => 'Charity',
			'heading'    => 'From Heart to Heart: The Journey of Donations through Every Pregnancy',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'pink',
			'url'        => '#',
		),
		array(
			'tag'        => 'Kids',
			'heading'    => 'Championing Maternal Strength: The Story of Every Pregnancy',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'cocoa',
			'url'        => '#',
		),
		array(
			'tag'        => 'Kids',
			'heading'    => 'Every Pregnancy: Building a Better Future for Mothers and Families',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'pink',
			'url'        => '#',
		),
		array(
			'tag'        => 'Kids',
			'heading'    => 'Together We Rise: The Power of Community Support for Mothers through Every Pregnancy',
			'author'     => 'Every Pregnancy',
			'date'       => 'August 20, 2022',
			'image'      => '',
			'image_tone' => 'pink',
			'url'        => '#',
		),
	),
);
