<?php
/**
 * Page template — renders any standard WP page (e.g. /blogs/) with the
 * full-bleed block layout, no article wrapper or page title. Mirrors
 * front-page.php so block-driven pages look the same as the homepage.
 *
 * @package EveryPregnancy
 */

get_header();
?>
<main id="primary" class="site-main site-main--page">
	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
	endif;
	?>
</main>
<?php
get_footer();
