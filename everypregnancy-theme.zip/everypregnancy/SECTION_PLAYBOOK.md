# Section Block Playbook

Every section in EveryPregnancy is built as a custom ACF block following the
Clearoute classic-theme pattern. This playbook is the contract every agent
follows so the blocks compose cleanly on the homepage.

## Theme location

`/Users/sheharyar/Studio/everypregnancy-demo/wp-content/themes/everypregnancy/`

## Where to put files

```
blocks/
└── <slug>/
    ├── block.json          # Block registration (apiVersion 3)
    ├── <slug>.php          # Render template (uses get_field())
    ├── <slug>.css          # Scoped styles, ep-<slug>__ namespace
    └── preview_data.php    # Editor preview fallbacks

acf-json/
└── group_<slug>.json       # ACF field group, location: everypregnancy/<slug>
```

The theme auto-discovers everything under `blocks/<slug>/block.json` via the
`everypregnancy_register_blocks()` function in `functions.php`. **Do not edit
functions.php** — auto-discovery handles registration.

## Naming

- Block name: `everypregnancy/<slug>` (slug is kebab-case)
- CSS class root: `ep-<slug>` (kebab from the slug, e.g. `ep-stats-row`)
- ACF field group key: `group_<slug>`
- ACF field keys: `field_<slug>_<name>` (e.g. `field_stats_row_heading`)

## Design tokens

`design-tokens.json` (root of the theme) is the source of truth for colors,
typography, spacing. Always reference it. **Don't invent values.** All
colors must be one of:

```
off-white  #fbf9f6   stone   #efe8da   powder   #ffccc7   blush    #e8aaa7
cocoa      #8f491a   conker  #7c3b0f   conker-2 #601f0b   walnut   #3f0e03
teal       #0f7d83   hero-bg #f7f4e8
nav-text   #5f2110 (used in navbar items only — slight tonal shift from conker-2)
```

Typography: Barlow (heading), Barlow Condensed (subhead), Outfit (body, light).
Script accent (for cursive words like "safe" and "born"): **Allison** —
closest Google Fonts free substitute for the Figma's Des Montilles. Available
as font family slug `script` in theme.json. Use the CSS variable:

```
font-family: var(--wp--preset--font-family--script);
```

Use `theme.json` CSS variables in CSS:
- `var(--wp--preset--color--cocoa)`
- `var(--wp--preset--font-family--barlow)`
- `var(--wp--preset--font-family--script)`
- `var(--wp--preset--font-size--body)`

## Asset downloads from Figma MCP

Figma's `get_design_context` tool returns asset URLs like
`http://localhost:3845/assets/<hash>.png` (or .svg). These can be downloaded
via plain `curl` GET (HEAD requests return 404 — that's normal, ignore the
404, just GET the body):

```bash
curl -s "http://localhost:3845/assets/<hash>.png" -o "<theme>/src/img/<name>.png"
file "<theme>/src/img/<name>.png"   # verify it's a real image
```

When an agent needs to bundle a Figma asset (logo, icon, photo) into the
theme, save it to `src/img/` (or `src/svg/` for SVGs) and reference via
`get_template_directory_uri() . '/src/img/<name>.png'` in PHP. Do NOT
hard-code the localhost:3845 URL into rendered output — those URLs expire
when Figma desktop closes.

## Reference: hero block

The hero block (`blocks/hero/`) is your canonical example. Copy its file
shapes. Same conventions for everything you produce.

## How to extract Figma values for your section

The Figma Dev Mode MCP server is running locally on `127.0.0.1:3845/mcp`.
Use `/tmp/figma-mcp.sh <tool_name> '<json_args>'` to call it.

Required: extract design context for your assigned node ID:

```bash
/tmp/figma-mcp.sh get_design_context '{"nodeId":"<your-node-id>","clientFrameworks":"react","clientLanguages":"tsx,css"}'
```

Save the output, parse the colors / fonts / dimensions, map to design-tokens.json
values, then build.

To screenshot your section for visual reference:

```bash
/tmp/figma-mcp.sh get_screenshot '{"nodeId":"<your-node-id>"}'
```

(returns base64-encoded PNG in the `result.content[].data` field)

## block.json template

```json
{
  "$schema": "https://schemas.wp.org/trunk/block.json",
  "apiVersion": 3,
  "name": "everypregnancy/<slug>",
  "version": "0.1.0",
  "title": "<Human title>",
  "description": "<one sentence>",
  "category": "theme",
  "icon": "<dashicon>",
  "keywords": ["<tag>"],
  "textdomain": "everypregnancy",
  "supports": { "anchor": true, "align": false, "html": false },
  "acf": { "mode": "preview", "renderTemplate": "<slug>.php" },
  "style": "file:./<slug>.css"
}
```

## Render template skeleton

```php
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$h = get_field( 'heading' );
// ... etc

if ( ! empty( $is_preview ) ) {
    $preview = require __DIR__ . '/preview_data.php';
    $h = $h ?: $preview['heading'];
}

$id = $block['anchor'] ?? '<slug>-' . wp_unique_id();
?>
<section id="<?php echo esc_attr( $id ); ?>" class="ep-<slug>">
    <!-- markup, escaping every value -->
</section>
```

## ACF field group JSON template

```json
{
  "key": "group_<slug>",
  "title": "<Human Title> (Block Fields)",
  "fields": [
    {
      "key": "field_<slug>_heading",
      "label": "Heading",
      "name": "heading",
      "type": "text",
      "default_value": "..."
    }
  ],
  "location": [[
    { "param": "block", "operator": "==", "value": "acf/everypregnancy-<slug>,everypregnancy/<slug>" }
  ]],
  "active": true,
  "modified": 1746576000
}
```

After writing the JSON, sync it via:
```bash
cd /Users/sheharyar/Studio/everypregnancy-demo && studio wp acf json sync
```

## Verifying your block

After writing all four files + the field group JSON:

```bash
# Confirm registration
cd /Users/sheharyar/Studio/everypregnancy-demo
studio wp eval '$r = WP_Block_Type_Registry::get_instance(); echo $r->get_registered("everypregnancy/<slug>") ? "ok" : "missing";'

# Render against a temp post to verify markup
studio wp eval '
echo do_blocks("<!-- wp:everypregnancy/<slug> {\"data\":{...}} /-->");
'
```

## Responsive

- Mobile-first.
- Desktop breakpoint: `@media (min-width: 992px)`.
- Test at 375px and 1440px.

## Accessibility minimum

- Every image needs an `alt`.
- Every button needs a label or aria-label.
- Heading levels: hero is h1; later sections start at h2.
- Decorative SVGs use `aria-hidden="true"`.

## What NOT to do

- Don't touch `functions.php` (auto-discovery handles you).
- Don't touch `style.css` (the WP header file — comment-only).
- Don't touch other blocks' files.
- Don't edit the homepage post (the orchestrator stitches it).
- Don't add new dependencies (no npm, no composer).
- Don't reach into wp-admin (no `studio wp` calls except for `acf json sync` and verification).
- Don't invent design values — every CSS value maps to design-tokens.json or theme.json.
