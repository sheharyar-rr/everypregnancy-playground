<?php
/**
 * Default template — required for any classic theme. Pages with a custom
 * template fall through to here only if no more specific template matches.
 *
 * @package EveryPregnancy
 */

get_header();
?>
<main id="primary" class="site-main">
	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<header class="entry-header">
					<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
				</header>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</article>
			<?php
		endwhile;
	else :
		?>
		<p><?php esc_html_e( 'Nothing to display yet.', 'everypregnancy' ); ?></p>
		<?php
	endif;
	?>
</main>
<?php
get_footer();
