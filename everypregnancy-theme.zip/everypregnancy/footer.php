<?php
/**
 * @package EveryPregnancy
 */
?>
<?php get_template_part( 'template-parts/site-footer' ); ?>
<?php wp_footer(); ?>
</body>
</html>
