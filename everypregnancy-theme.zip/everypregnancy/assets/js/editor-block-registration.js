/**
 * Editor-side registration for server-rendered EveryPregnancy ACF blocks.
 *
 * Blocks are declared via /blocks/<slug>/block.json and registered in PHP
 * via register_block_type(). That populates the server-side registry and
 * makes the blocks render correctly on the frontend, but the Gutenberg
 * editor only knows about blocks present in its JS-side registry. With
 * ACF Free (no auto-bridge), block.json blocks without an explicit
 * editorScript do not get auto-registered client-side, so the editor
 * shows them as "unsupported."
 *
 * This shim fetches the server-registered list from /wp/v2/block-types
 * and registers every theme block in the editor's JS registry, using
 * ServerSideRender to fetch the live preview from PHP. After this runs,
 * "Edit Page" shows the blocks rendered with their saved ACF data.
 */
( function () {
	const wp = window.wp;
	if ( ! wp || ! wp.apiFetch || ! wp.blocks || ! wp.element ) {
		return;
	}

	const themeNamespace = ( window.everypregnancyEditorBootstrap && window.everypregnancyEditorBootstrap.namespace )
		|| 'everypregnancy/';

	wp.domReady( async () => {
		const ServerSideRender = wp.serverSideRender || ( wp.editor && wp.editor.ServerSideRender );
		if ( ! ServerSideRender ) {
			console.warn( '[EveryPregnancy] ServerSideRender unavailable; cannot register editor previews.' );
			return;
		}

		let types;
		try {
			types = await wp.apiFetch( { path: '/wp/v2/block-types' } );
		} catch ( e ) {
			console.error( '[EveryPregnancy] Failed to load block types from REST:', e );
			return;
		}

		const { registerBlockType, getBlockType } = wp.blocks;
		const { createElement } = wp.element;

		for ( const b of types ) {
			if ( ! b.name || ! b.name.startsWith( themeNamespace ) ) continue;
			if ( getBlockType( b.name ) ) continue;

			try {
				registerBlockType( b.name, {
					apiVersion: b.api_version || 3,
					title: b.title || b.name,
					category: b.category || 'theme',
					icon: b.icon || 'block-default',
					description: b.description || '',
					attributes: b.attributes || {},
					supports: b.supports || {},
					edit: ( props ) => createElement(
						ServerSideRender,
						{
							block: b.name,
							attributes: props.attributes,
							httpMethod: 'POST',
						}
					),
					save: () => null,
				} );
			} catch ( e ) {
				console.error( `[EveryPregnancy] Failed to register ${ b.name }:`, e );
			}
		}

		// After registration, force the editor to re-parse the current post so
		// previously "core/missing" blocks pick up their real definitions.
		const { select, dispatch } = wp.data;
		const content = select( 'core/editor' ) && select( 'core/editor' ).getEditedPostAttribute( 'content' );
		if ( content && wp.blocks.parse ) {
			const blocks = wp.blocks.parse( content );
			dispatch( 'core/block-editor' ).resetBlocks( blocks );
		}
	} );
} )();
