<?php
/**
 * Homepage template — runs whenever the site root is requested AND a static
 * page is set as the front page. Renders the assigned page's content (which
 * carries the ACF blocks).
 *
 * @package EveryPregnancy
 */

get_header();
?>
<main id="primary" class="site-main site-main--home">
	<?php
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			the_content();
		endwhile;
	endif;
	?>
</main>
<?php
get_footer();
