<?php
/**
 * Site Header template part.
 *
 * Sitewide navigation bar for EveryPregnancy. The desktop bar has 5 links +
 * a teal CTA. The mobile menu is a full-screen overlay with the same items
 * stacked vertically, including an expandable "Our Partners" sub-menu.
 *
 * Content (logo, nav HTML, CTA) comes from the Header Settings ACF Options
 * page; everypregnancy_header_field() falls back to canonical defaults.
 *
 * The mobile toggle is wired with a tiny inline script — no external JS
 * dependency.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$logo_url  = (string) everypregnancy_header_field( 'logo' );
$logo_alt  = (string) everypregnancy_header_field( 'logo_alt' );
$nav_html  = (string) everypregnancy_header_field( 'nav_html' );
$cta_label = (string) everypregnancy_header_field( 'cta_label' );
$cta_url   = (string) everypregnancy_header_field( 'cta_url' );

$home_url = home_url( '/' );

/*
 * Inline SVGs.
 * - Hamburger: 3-line icon for the closed mobile menu trigger.
 * - Close (X): swaps in when the menu is open.
 * - Chevron-down: appended to nav items that have a sub-menu (Our Partners).
 */
$hamburger_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>';
$close_svg     = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><line x1="6" y1="6" x2="18" y2="18"/><line x1="6" y1="18" x2="18" y2="6"/></svg>';

$svg_kses = array(
	'svg'  => array( 'xmlns' => true, 'width' => true, 'height' => true, 'viewbox' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'aria-hidden' => true, 'focusable' => true, 'class' => true ),
	'line' => array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true ),
	'path' => array( 'd' => true, 'fill' => true ),
);

// Allow nested <ul>, <li>, <a>, <span> + the chevron SVG (svg + polyline).
$kses_nav = array(
	'ul'       => array( 'class' => true ),
	'ol'       => array( 'class' => true ),
	'li'       => array( 'class' => true ),
	'a'        => array( 'href' => true, 'title' => true, 'rel' => true, 'target' => true, 'class' => true, 'aria-haspopup' => true, 'aria-expanded' => true ),
	'span'     => array( 'class' => true, 'aria-hidden' => true ),
	'svg'      => array( 'xmlns' => true, 'width' => true, 'height' => true, 'viewbox' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'aria-hidden' => true, 'focusable' => true, 'class' => true ),
	'polyline' => array( 'points' => true ),
	'path'     => array( 'd' => true, 'fill' => true ),
	'line'     => array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true ),
);

/*
 * Inject a chevron into any list item flagged `has-children` so the editor
 * markup stays clean (no inline SVG in the wysiwyg). We post-process the nav
 * HTML once before kses runs.
 */
$chevron_svg = '<span class="ep-site-header__chevron" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><polyline points="6 9 12 15 18 9"/></svg></span>';
$svg_kses['polyline'] = array( 'points' => true );
// Inject the chevron INSIDE the <a> tag so flex layout puts it beside the
// text rather than wrapping it to the next line.
$nav_html_with_chevrons = preg_replace_callback(
	'/<li class="has-children">\s*<a([^>]*)>([^<]*)<\/a>/i',
	function ( $m ) use ( $chevron_svg ) {
		return '<li class="has-children"><a' . $m[1] . '>' . $m[2] . $chevron_svg . '</a>';
	},
	$nav_html
);
?>
<header class="ep-site-header" role="banner">
	<div class="ep-site-header__inner">

		<a class="ep-site-header__brand" href="<?php echo esc_url( $home_url ); ?>" aria-label="<?php echo esc_attr( $logo_alt ); ?>">
			<?php if ( $logo_url ) : ?>
				<img class="ep-site-header__logo" src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( $logo_alt ); ?>" />
			<?php else : ?>
				<span class="ep-site-header__brand-text"><?php echo esc_html( $logo_alt ); ?></span>
			<?php endif; ?>
		</a>

		<nav class="ep-site-header__nav" aria-label="<?php esc_attr_e( 'Primary', 'everypregnancy' ); ?>">
			<?php echo wp_kses( $nav_html_with_chevrons, $kses_nav ); ?>
		</nav>

		<?php if ( $cta_label ) : ?>
			<a class="ep-site-header__cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>

		<button type="button" class="ep-site-header__toggle" aria-label="<?php esc_attr_e( 'Open menu', 'everypregnancy' ); ?>" aria-expanded="false" aria-controls="ep-site-header-mobile">
			<span class="ep-site-header__toggle-icon ep-site-header__toggle-icon--open"><?php echo wp_kses( $hamburger_svg, $svg_kses ); ?></span>
			<span class="ep-site-header__toggle-icon ep-site-header__toggle-icon--close"><?php echo wp_kses( $close_svg, $svg_kses ); ?></span>
		</button>

	</div>

	<!-- Mobile menu (full-screen overlay; opened by the toggle above) -->
	<div id="ep-site-header-mobile" class="ep-site-header__mobile" hidden>
		<nav class="ep-site-header__mobile-nav" aria-label="<?php esc_attr_e( 'Mobile primary', 'everypregnancy' ); ?>">
			<?php echo wp_kses( $nav_html_with_chevrons, $kses_nav ); ?>
		</nav>
		<?php if ( $cta_label ) : ?>
			<a class="ep-site-header__mobile-cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>
	</div>
</header>

<script>
(function () {
	var header = document.querySelector('.ep-site-header');
	if (!header) return;
	var toggle = header.querySelector('.ep-site-header__toggle');
	var mobile = header.querySelector('.ep-site-header__mobile');
	if (!toggle || !mobile) return;

	function setOpen(open) {
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
		mobile.hidden = !open;
		header.classList.toggle('is-mobile-open', open);
		document.body.classList.toggle('ep-no-scroll', open);
	}

	toggle.addEventListener('click', function () {
		setOpen(toggle.getAttribute('aria-expanded') !== 'true');
	});

	// Submenu expand/collapse on tap (mobile only — desktop uses :hover)
	mobile.querySelectorAll('li.has-children > a').forEach(function (a) {
		a.addEventListener('click', function (e) {
			var li = a.parentElement;
			if (li.classList.toggle('is-open')) {
				e.preventDefault();
			}
		});
	});

	// Close on ESC
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
			setOpen(false);
			toggle.focus();
		}
	});
})();
</script>
