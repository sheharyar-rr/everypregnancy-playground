<?php
/**
 * Site Footer template part.
 *
 * Sitewide footer for EveryPregnancy. User-facing content (links, social
 * URLs, copyright text) comes from the "Footer Settings" ACF Options page;
 * everypregnancy_footer_field() falls back to canonical defaults so the
 * footer always renders something sensible — even before the editor
 * configures it.
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$quick_links_heading = (string) everypregnancy_footer_field( 'quick_links_heading' );
$quick_links_html    = (string) everypregnancy_footer_field( 'quick_links_html' );
$contact_heading     = (string) everypregnancy_footer_field( 'contact_heading' );
$contact_email       = (string) everypregnancy_footer_field( 'contact_email' );
$social_heading      = (string) everypregnancy_footer_field( 'social_heading' );
$social_instagram    = (string) everypregnancy_footer_field( 'social_instagram' );
$social_facebook     = (string) everypregnancy_footer_field( 'social_facebook' );
$social_tiktok       = (string) everypregnancy_footer_field( 'social_tiktok' );
$social_youtube      = (string) everypregnancy_footer_field( 'social_youtube' );
$social_linkedin     = (string) everypregnancy_footer_field( 'social_linkedin' );
$copyright_template  = (string) everypregnancy_footer_field( 'copyright_text' );

$year      = date_i18n( 'Y' );
$copyright = str_replace( '{year}', $year, $copyright_template );

// Render the bullet/dot separator (Figma uses an 8px filled circle, not the
// "•" glyph) by splitting on the literal bullet character if present.
$copyright_parts = array_map( 'trim', explode( '•', $copyright ) );

// Inline SVG icons — sourced to match the Iconify icons referenced in Figma:
// mdi:instagram, ic:baseline-facebook, ic:sharp-tiktok, iconoir:youtube,
// ant-design:linkedin-outlined. 24px viewBox, currentColor fill.
$icons = array(
	'instagram' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4zm9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3"/></svg>',
	'facebook'  => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20 3H4a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h8.62v-7h-2.35v-2.69h2.35v-2c0-2.33 1.42-3.6 3.5-3.6c1 0 1.84.07 2.1.11v2.43h-1.44c-1.13 0-1.35.53-1.35 1.32v1.74h2.69L17.78 14h-2.35v7H20a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1"/></svg>',
	'tiktok'    => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74a2.89 2.89 0 0 1 2.31-4.64a2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1.84-.1z"/></svg>',
	'youtube'   => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M14 12L10.5 14V10L14 12Z" fill="currentColor"/><path d="M2 12.708v-1.416c0-2.898 0-4.346.93-5.265c.93-.92 2.394-.97 5.32-1.071c1.388-.048 2.806-.082 4.25-.082c1.444 0 2.862.034 4.25.082c2.926.101 4.39.151 5.32 1.07c.93.92.93 2.368.93 5.266v1.416c0 2.898 0 4.347-.93 5.266c-.93.92-2.394.97-5.32 1.071c-1.388.048-2.806.082-4.25.082c-1.444 0-2.862-.034-4.25-.082c-2.926-.101-4.39-.152-5.32-1.07C2 17.054 2 15.606 2 12.707"/></svg>',
	'linkedin'  => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04c-1.86 0-2.14 1.45-2.14 2.94v5.67H9.36V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85c3.6 0 4.27 2.37 4.27 5.46zM5.34 7.43a2.06 2.06 0 0 1-2.07-2.07c0-1.14.93-2.07 2.07-2.07a2.07 2.07 0 0 1 0 4.14M7.12 20.45H3.56V9h3.56zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0"/></svg>',
);

$social_links = array(
	'instagram' => array( 'url' => $social_instagram, 'label' => __( 'Instagram', 'everypregnancy' ) ),
	'facebook'  => array( 'url' => $social_facebook,  'label' => __( 'Facebook',  'everypregnancy' ) ),
	'tiktok'    => array( 'url' => $social_tiktok,    'label' => __( 'TikTok',    'everypregnancy' ) ),
	'youtube'   => array( 'url' => $social_youtube,   'label' => __( 'YouTube',   'everypregnancy' ) ),
	'linkedin'  => array( 'url' => $social_linkedin,  'label' => __( 'LinkedIn',  'everypregnancy' ) ),
);

// Allow <ul>, <li>, <a> in the quick-links HTML.
$kses_links = array(
	'ul' => array( 'class' => true ),
	'ol' => array( 'class' => true ),
	'li' => array( 'class' => true ),
	'a'  => array( 'href' => true, 'title' => true, 'rel' => true, 'target' => true, 'class' => true ),
);
?>
<footer class="ep-site-footer" role="contentinfo">
	<div class="ep-site-footer__inner">
		<div class="ep-site-footer__grid">

			<section class="ep-site-footer__col ep-site-footer__col--links" aria-labelledby="ep-footer-links-heading">
				<h2 id="ep-footer-links-heading" class="ep-site-footer__heading"><?php echo esc_html( $quick_links_heading ); ?></h2>
				<div class="ep-site-footer__links">
					<?php echo wp_kses( $quick_links_html, $kses_links ); ?>
				</div>
			</section>

			<section class="ep-site-footer__col ep-site-footer__col--contact" aria-labelledby="ep-footer-contact-heading">
				<h2 id="ep-footer-contact-heading" class="ep-site-footer__heading"><?php echo esc_html( $contact_heading ); ?></h2>
				<?php if ( $contact_email ) : ?>
					<p class="ep-site-footer__contact">
						<a href="mailto:<?php echo esc_attr( $contact_email ); ?>"><?php echo esc_html( $contact_email ); ?></a>
					</p>
				<?php endif; ?>
			</section>

			<section class="ep-site-footer__col ep-site-footer__col--social" aria-labelledby="ep-footer-social-heading">
				<h2 id="ep-footer-social-heading" class="ep-site-footer__heading"><?php echo esc_html( $social_heading ); ?></h2>
				<ul class="ep-site-footer__socials">
					<?php foreach ( $social_links as $key => $social ) :
						$icon = $icons[ $key ] ?? '';
						if ( ! $icon ) {
							continue;
						}
						$svg_kses = array(
							'svg'    => array( 'xmlns' => true, 'width' => true, 'height' => true, 'viewbox' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true, 'aria-hidden' => true, 'focusable' => true ),
							'rect'   => array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true ),
							'circle' => array( 'cx' => true, 'cy' => true, 'r' => true, 'fill' => true, 'stroke' => true ),
							'path'   => array( 'd' => true, 'fill' => true, 'stroke' => true ),
						);
					?>
						<li class="ep-site-footer__social">
							<?php if ( ! empty( $social['url'] ) ) : ?>
								<a href="<?php echo esc_url( $social['url'] ); ?>" rel="noopener noreferrer" target="_blank" aria-label="<?php echo esc_attr( $social['label'] ); ?>">
									<?php echo wp_kses( $icon, $svg_kses ); ?>
								</a>
							<?php else : ?>
								<span aria-hidden="true"><?php echo wp_kses( $icon, $svg_kses ); ?></span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>

		</div>

		<hr class="ep-site-footer__divider" aria-hidden="true" />

		<p class="ep-site-footer__copyright">
			<?php
			$last = count( $copyright_parts ) - 1;
			foreach ( $copyright_parts as $i => $part ) :
				if ( $part === '' ) {
					continue;
				}
				?>
				<span class="ep-site-footer__copyright-text"><?php echo esc_html( $part ); ?></span>
				<?php if ( $i < $last ) : ?>
					<span class="ep-site-footer__copyright-dot" aria-hidden="true"></span>
				<?php endif; ?>
			<?php endforeach; ?>
		</p>
	</div>
</footer>
