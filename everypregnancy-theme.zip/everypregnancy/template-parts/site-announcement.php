<?php
/**
 * Site Announcement Bar.
 *
 * Sits ABOVE the navbar in header.php. Pink/blush background with a campaign
 * eyebrow + body + brown CTA button. Responsive: desktop is single-row with
 * inline text + button; mobile collapses to short body line + full-width
 * button below, navbar follows underneath.
 *
 * Figma source: 6729:29 (desktop) / 6729:35 (mobile).
 *
 * @package EveryPregnancy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! everypregnancy_announcement_field( 'show' ) ) {
	return;
}

$icon        = (string) everypregnancy_announcement_field( 'icon' );
$icon_alt    = (string) everypregnancy_announcement_field( 'icon_alt' );
$eyebrow     = (string) everypregnancy_announcement_field( 'eyebrow' );
$body        = (string) everypregnancy_announcement_field( 'body' );
$body_mobile = (string) everypregnancy_announcement_field( 'body_mobile' );
$cta_label   = (string) everypregnancy_announcement_field( 'cta_label' );
$cta_url     = (string) everypregnancy_announcement_field( 'cta_url' );
?>
<aside class="ep-site-announcement" role="region" aria-label="<?php esc_attr_e( 'Site announcement', 'everypregnancy' ); ?>">
	<div class="ep-site-announcement__inner">
		<?php if ( $icon ) : ?>
			<div class="ep-site-announcement__icon" aria-hidden="true">
				<img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $icon_alt ); ?>" />
			</div>
		<?php endif; ?>

		<div class="ep-site-announcement__text">
			<?php if ( $eyebrow ) : ?>
				<span class="ep-site-announcement__eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
			<?php endif; ?>
			<?php if ( $body ) : ?>
				<span class="ep-site-announcement__body"><?php echo esc_html( $body ); ?></span>
			<?php endif; ?>
			<?php if ( $body_mobile ) : ?>
				<span class="ep-site-announcement__body ep-site-announcement__body--mobile"><?php echo esc_html( $body_mobile ); ?></span>
			<?php endif; ?>
		</div>

		<?php if ( $cta_label ) : ?>
			<a class="ep-site-announcement__cta" href="<?php echo esc_url( $cta_url ?: '#' ); ?>">
				<?php echo esc_html( $cta_label ); ?>
			</a>
		<?php endif; ?>
	</div>
</aside>
